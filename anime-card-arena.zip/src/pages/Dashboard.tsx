import { useState, useEffect } from 'react';
import { useAuth } from '../lib/useAuth';
import { db } from '../lib/firebase';
import { collection, query, limit, getDocs, getDoc, orderBy, doc, updateDoc } from 'firebase/firestore';
import { Trophy, Users, Swords, Gift, Calendar, CheckCircle2, Edit2, Check, X, Shield } from 'lucide-react';
import { UserProfile } from '../types';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const { user, profile } = useAuth();

  const [leaderboard, setLeaderboard] = useState<UserProfile[]>([]);
  const [strongestCards, setStrongestCards] = useState<any[]>([]);
  
  const [claiming, setClaiming] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [newName, setNewName] = useState('');


  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        const q = query(collection(db, 'users2'), orderBy('points', 'desc'), limit(20));
        const snap = await getDocs(q);
        const allUsers = snap.docs.map(d => ({ id: d.id, ...d.data() } as UserProfile));
        const filtered = allUsers.filter(u => u.email !== 'miguelrafaelmontana@gmail.com').slice(0, 5);
        setLeaderboard(filtered);
      } catch (err) {
        console.error(err);
      }
    };
    fetchLeaderboard();

    const fetchStrongest = async () => {
      try {
        const cq = query(collection(db, 'cards2'), orderBy('power', 'desc'), limit(25));
        const cSnap = await getDocs(cq);
        const allCards = cSnap.docs.map(d => ({ id: d.id, ...d.data() }));
        const filteredCards = allCards.filter(c => !c.id.startsWith('admin_')).slice(0, 5);
        setStrongestCards(filteredCards);
      } catch (err) {
        console.error(err);
      }
    };
    fetchStrongest();


  }, []);

  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  const hasClaimedToday = profile?.lastClaimDate === today;
  const hasClaimedYesterday = profile?.lastClaimDate === yesterdayStr;
  
  let activeStreak = profile?.streakCount || 0;
  if (!hasClaimedToday && !hasClaimedYesterday) {
    activeStreak = 0;
  }

  const nextReward = hasClaimedToday ? (activeStreak + 1) * 200 : (activeStreak + 1) * 200;

  
  const handleSaveName = async () => {
    if (!user || !newName.trim()) return;
    try {
      await updateDoc(doc(db, 'users2', user.uid), { displayName: newName.trim() });
      setEditingName(false);
    } catch (e) {
      console.error(e);
      alert("Failed to update name");
    }
  };


  const handleClaimDaily = async () => {
    if (!user || !profile || hasClaimedToday || claiming) return;
    setClaiming(true);
    
    try {
      const newStreak = hasClaimedYesterday ? (profile.streakCount || 0) + 1 : 1;
      const reward = newStreak * 200;
      
      await updateDoc(doc(db, 'users2', user.uid), {
        points: (profile.points || 0) + reward,
        lastClaimDate: today,
        streakCount: newStreak
      });
    } catch (err) {
      console.error(err);
    } finally {
      setClaiming(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      <header className="mb-8">
        {editingName ? (
          <div className="flex items-center gap-3 mb-2">
             <input 
               type="text" 
               className="bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-2xl font-black focus:outline-none focus:border-blue-500" 
               value={newName} 
               onChange={e => setNewName(e.target.value)}
               placeholder={profile?.displayName}
               autoFocus
             />
             <button onClick={handleSaveName} className="p-2 bg-green-600 hover:bg-green-500 rounded-xl text-white transition-colors"><Check size={20}/></button>
             <button onClick={() => setEditingName(false)} className="p-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-white transition-colors"><X size={20}/></button>
          </div>
        ) : (
          <h1 className="text-4xl font-black tracking-tight mb-2 group flex items-center gap-4">
            Welcome, {profile?.displayName?.split(' ')[0]}
            {profile?.email === 'miguelrafaelmontana@gmail.com' && (
               <span className="bg-red-500/20 text-red-400 text-sm px-2 py-1 rounded-lg border border-red-500/50 flex items-center gap-1 font-bold">
                 <Shield size={16} /> ADMIN
               </span>
            )}
            <button onClick={() => { setNewName(profile?.displayName || ''); setEditingName(true); }} className="opacity-0 group-hover:opacity-100 p-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-slate-400 hover:text-white transition-all"><Edit2 size={16}/></button>
          </h1>
        )}
        <p className="text-slate-400 text-lg">Your current rank is <span className="text-blue-400 font-bold">#{profile?.rank || 'Unranked'}</span> with {profile?.points || 0} points.</p>
      </header>


      {/* Daily Reward Section */}
      <div className="bg-gradient-to-r from-blue-900/40 to-indigo-900/40 border border-blue-500/30 rounded-3xl p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-[0_0_30px_rgba(59,130,246,0.15)] relative overflow-hidden">
        <div className="absolute -right-12 -top-12 opacity-10">
          <Gift size={200} />
        </div>
        <div className="z-10 flex items-center gap-6">
          <div className="bg-blue-600 p-4 rounded-2xl shadow-[0_0_20px_rgba(59,130,246,0.4)]">
            <Calendar size={32} className="text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-white mb-1">Daily Reward</h2>
            <p className="text-blue-200">
              Current Streak: <span className="font-bold text-white">{activeStreak} days</span> 
              {!hasClaimedToday && <span className="ml-2 text-yellow-400">(Claim today to keep it!)</span>}
            </p>
          </div>
        </div>
        
        <div className="z-10 w-full md:w-auto">
          {hasClaimedToday ? (
             <div className="bg-slate-800/80 border border-slate-700 px-6 py-4 rounded-2xl flex items-center gap-3 text-slate-300">
                <CheckCircle2 className="text-green-400" />
                <span className="font-bold">Claimed! Next reward: {nextReward} pts</span>
             </div>
          ) : (
             <button 
               onClick={handleClaimDaily}
               disabled={claiming}
               className="w-full md:w-auto bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400 text-slate-900 px-8 py-4 rounded-2xl font-black text-lg transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(250,204,21,0.4)] flex items-center justify-center gap-2 disabled:opacity-50"
             >
               <Gift size={24} />
               CLAIM {nextReward} PTS
             </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <DashboardCard 
          title="Battle Arena" 
          description="Join 1v1 matchmaking and climb the global ranks."
          icon={<Swords size={32} className="text-red-400" />}
          href="/arena"
          bg="bg-gradient-to-br from-red-500/10 to-transparent border-red-500/20"
        />
        <DashboardCard 
          title="My Collection" 
          description="View your rare anime cards and build your deck."
          icon={<Trophy size={32} className="text-yellow-400" />}
          href="/collection"
          bg="bg-gradient-to-br from-yellow-500/10 to-transparent border-yellow-500/20"
        />
        <DashboardCard 
          title="Friends & Groups" 
          description="Share videos, chat, and challenge your friends."
          icon={<Users size={32} className="text-green-400" />}
          href="/friends"
          bg="bg-gradient-to-br from-green-500/10 to-transparent border-green-500/20"
        />
      </div>

      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-16">
        <div>
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
            <Trophy className="text-yellow-500" /> Top Players
          </h2>
          <div className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
            {leaderboard.length === 0 ? (
              <div className="p-8 text-center text-slate-500">No players ranked yet.</div>
            ) : (
              <div className="divide-y divide-slate-700/50">
                {leaderboard.map((u, i) => (
                  <div key={u.id} className="p-4 flex items-center gap-4 hover:bg-slate-700/20 transition-colors">
                    <div className="w-8 font-mono text-slate-500 font-bold text-lg">#{i + 1}</div>
                    <img 
                       src={u.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${u.displayName}`} 
                       className="w-10 h-10 rounded-full bg-slate-700 object-cover"
                    />
                    <div className="flex-1 font-medium">{u.displayName}</div>
                    <div className="text-blue-400 font-bold">{u.points || 0} pts</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
            <Swords className="text-red-500" /> Strongest Cards
          </h2>
          <div className="bg-slate-800/50 rounded-2xl border border-slate-700 overflow-hidden">
            {strongestCards.length === 0 ? (
              <div className="p-8 text-center text-slate-500">No cards discovered yet.</div>
            ) : (
              <div className="divide-y divide-slate-700/50">
                {strongestCards.map((c, i) => (
                  <div key={c.id} className="p-4 flex items-center gap-4 hover:bg-slate-700/20 transition-colors">
                    <div className="w-8 font-mono text-slate-500 font-bold text-lg">#{i + 1}</div>
                    <img 
                       src={c.imageURL} 
                       className="w-12 h-12 rounded-lg bg-slate-700 object-cover border border-slate-600"
                    />
                    <div className="flex-1">
                       <div className="font-bold flex items-center gap-2">
                          {c.name}
                          {c.isShiny && <span className="text-[10px] bg-yellow-400/20 text-yellow-400 px-2 py-0.5 rounded uppercase font-black">Shiny</span>}
                       </div>
                       <div className="text-xs text-slate-400">Owned by: <span className="text-white font-medium">{c.ownerName}</span></div>
                    </div>
                    <div className="text-red-400 font-black flex flex-col items-end">
                       <span>{c.displayPower} PWR</span>
                       <span className="text-[10px] font-medium text-slate-500">{c.rarity.toUpperCase()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}


function DashboardCard({ title, description, icon, href, bg }: any) {
  return (
    <Link to={href} className={`block p-6 rounded-3xl border border-slate-700 hover:border-slate-500 transition-all hover:scale-[1.02] ${bg}`}>
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-slate-400 text-sm">{description}</p>
    </Link>
  );
}
