import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/useAuth';
import { db } from '../lib/firebase';
import { collection, query, getDocs, doc, setDoc, deleteDoc, getDoc, updateDoc } from 'firebase/firestore';
import { generateCardData } from '../lib/api';
import { Loader2, Plus, Trash2, Edit3, Coins, RefreshCw } from 'lucide-react';
import { Card, UserCard } from '../types';
import AnimeCard from '../components/AnimeCard';
import SellModal from '../components/SellModal';

export default function Collection() {
  const { user, profile } = useAuth();
  const [cards, setCards] = useState<(UserCard & { cardData: Card })[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [generating, setGenerating] = useState(false);
  const [sellingCardId, setSellingCardId] = useState<string | null>(null);
  const [fixingImages, setFixingImages] = useState(false);

  useEffect(() => {
    fetchCards();
  }, [user]);

  const fetchCards = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const q = query(collection(db, 'users2', user.uid, 'cards2'));
      const snap = await getDocs(q);
      
      const loadedCards: (UserCard & { cardData: Card })[] = [];
      for (const d of snap.docs) {
        const userCard = { id: d.id, ...d.data() } as UserCard;
        const cardSnap = await getDoc(doc(db, 'cards2', userCard.cardId));
        if (cardSnap.exists()) {
          loadedCards.push({ ...userCard, cardData: { id: cardSnap.id, ...cardSnap.data() } as Card });
        }
      }
      setCards(loadedCards);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  
  const handleFixImages = async () => {
    if (!user) return;
    setFixingImages(true);
    try {
      let updatedCount = 0;
      const cardsToFix = cards.filter(card => !card.cardData.imageURL || card.cardData.imageURL.includes('dicebear') || card.cardData.imageURL.includes('default'));
      
      if (cardsToFix.length === 0) {
         alert("All your cards already have photos!");
         setFixingImages(false);
         return;
      }

      // Run sequentially to avoid rate limits on third-party APIs
      for (const card of cardsToFix) {
           try {
              const res = await fetch('/api/shop/fix-image', {
                 method: 'POST',
                 headers: { 'Content-Type': 'application/json' },
                 body: JSON.stringify({ searchQuery: card.cardData.searchQuery || card.cardData.name, anime: card.cardData.anime })
              });
              const data = await res.json();
              if (data.imageURL && !data.imageURL.includes('dicebear') && !data.imageURL.includes('default')) {
                 await updateDoc(doc(db, 'cards2', card.cardData.id), { imageURL: data.imageURL });
                 updatedCount++;
              }
           } catch (e) {
             console.error("Failed to fix", card.cardData.name);
           }
           // Small delay between requests to be safe
           await new Promise(r => setTimeout(r, 400));
      }

      if (updatedCount > 0) {
        alert(`Fixed ${updatedCount} missing photos!`);
        fetchCards();
      } else {
        alert("No missing photos could be fixed at this time. The characters might not have images available.");
      }
    } catch (e) {
      console.error(e);
      alert("Error fixing photos");
    }
    setFixingImages(false);
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!search.trim() || !user) return;
    setGenerating(true);
    try {
      // Create global card if not exists
      const newCardId = `card_${search.toLowerCase().replace(/\\s+/g, '_')}`;
      const cardRef = doc(db, 'cards2', newCardId);
      const cardSnap = await getDoc(cardRef);
      
      if (!cardSnap.exists()) {
        const cardData = await generateCardData(search);
        await setDoc(cardRef, { ...cardData, createdAt: Date.now() });
      }

      // Add to user collection
      const userCardId = `uc_${Date.now()}`;
      await setDoc(doc(db, 'users2', user.uid, 'cards2', userCardId), {
        cardId: newCardId,
        acquiredAt: Date.now()
      });

      setSearch('');
      await fetchCards();
    } catch (error) {
      console.error('Failed to generate', error);
      alert('Failed to generate card');
    }
    setGenerating(false);
  };

  
  
  const getSellValue = (rarity: string) => {
    switch (rarity) {
      case 'common': return 10;
      case 'rare': return 30;
      case 'epic': return 60;
      case 'legendary': return 150;
      case 'mythic': return 300;
      default: return 10;
    }
  };

  const handleEditPhoto = async (cardId: string) => {
    const newUrl = prompt("Enter a new image URL from Google (or anywhere else):");
    if (!newUrl || !newUrl.trim()) return;
    try {
      await updateDoc(doc(db, 'cards2', cardId), { imageURL: newUrl.trim() });
      setCards(cards.map(c => c.cardData.id === cardId ? { ...c, cardData: { ...c.cardData, imageURL: newUrl.trim() } } : c));
    } catch (e) {
      console.error(e);
      alert("Failed to update image.");
    }
  };

  
  
  
  
  const handleSell = async (price: number) => {
    if (!user || !profile || !sellingCardId) return;
    
    try {
      const cardToSell = cards.find(c => c.id === sellingCardId);
      if (!cardToSell) return;
      
      const listingId = `list_${Date.now()}`;
      await setDoc(doc(db, 'market2', listingId), {
        sellerId: user.uid,
        userCardId: cardToSell.cardId,
        price: price,
        status: 'open',
        createdAt: Date.now()
      });
      
      await deleteDoc(doc(db, 'users2', user.uid, 'cards2', sellingCardId));
      setCards(cards.filter(c => c.id !== sellingCardId));
      
      // We do not alert, modal handles close smoothly. 
    } catch (e) {
      console.error(e);
      alert("Failed to list card on market.");
    }
  };

  const handleDelete = async (userCardId: string) => {
    if (!user || !confirm('Discard this card?')) return;
    await deleteDoc(doc(db, 'users2', user.uid, 'cards2', userCardId));
    setCards(cards.filter(c => c.id !== userCardId));
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">My Collection</h1>
          <p className="text-slate-400">View and manage your discovered characters.</p>
        </div>
        
        <button 
          onClick={handleFixImages}
          disabled={fixingImages}
          className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors text-sm font-bold disabled:opacity-50"
        >
          {fixingImages ? <Loader2 size={16} className="animate-spin" /> : <RefreshCw size={16} />}
          {fixingImages ? "Fixing Photos..." : "Fix Missing Photos"}
        </button>
        
        <form onSubmit={handleGenerate} className="flex items-center gap-2">
          <input 
            type="text" 
            placeholder="E.g. Goku, Naruto..."
            className="bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 focus:outline-none focus:border-blue-500 transition-colors text-white"
            value={search}
            onChange={e => setSearch(e.target.value)}
            disabled={generating}
          />
          <button 
            type="submit" 
            disabled={generating || !search.trim()}
            className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-xl font-medium transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            {generating ? <Loader2 size={18} className="animate-spin" /> : <Plus size={18} />}
            Discover
          </button>
        </form>
      </header>

      {loading ? (
        <div className="flex justify-center p-12"><Loader2 className="animate-spin text-slate-500" size={32} /></div>
      ) : cards.length === 0 ? (
        <div className="text-center p-16 bg-slate-800/50 rounded-3xl border border-slate-700 border-dashed">
          <p className="text-slate-400 mb-4">You don't have any cards yet.</p>
          <p className="text-sm text-slate-500">Use the discovery tool above to search for anime characters and generate their cards.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {cards.map(c => (
            <div key={c.id} className="relative group p-2">
              <AnimeCard card={c.cardData} />
              
              <div className="absolute top-0 right-0 z-50 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-all">
                <button 
                  onClick={(e) => { e.stopPropagation(); setSellingCardId(c.id); }} 
                  className="bg-green-500 text-white p-3 rounded-full hover:bg-green-600 hover:scale-110 shadow-lg cursor-pointer"
                  title="List on Market"
                >
                  <Coins size={20} />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); handleEditPhoto(c.cardData.id); }} 
                  className="bg-blue-500 text-white p-3 rounded-full hover:bg-blue-600 hover:scale-110 shadow-lg cursor-pointer"
                  title="Change Photo"
                >
                  <Edit3 size={20} />
                </button>
              </div>
  
            </div>
          ))}
        </div>
      )}
    
      <SellModal 
        isOpen={!!sellingCardId}
        onClose={() => setSellingCardId(null)}
        onSell={handleSell}
      />
    </div>
  );
}
