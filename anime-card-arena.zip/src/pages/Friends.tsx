import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/useAuth';
import { db } from '../lib/firebase';
import { collection, query, getDocs, doc, setDoc, deleteDoc, where, onSnapshot } from 'firebase/firestore';
import { Loader2, UserPlus, Users, Video, UploadCloud, MessageCircle, Shield } from 'lucide-react';
import ChatModal from '../components/ChatModal';
import { UserProfile } from '../types';
import { uploadVideoToCatbox } from '../lib/upload';

export default function Friends() {
  const { user, profile } = useAuth();
  const [friends, setFriends] = useState<{ id: string, friend: UserProfile }[]>([]);
  const [loading, setLoading] = useState(true);
  const [addId, setAddId] = useState('');
  const [chattingWith, setChattingWith] = useState<{id: string, name: string} | null>(null);
  
  // Video sharing state
  const [videoUrl, setVideoUrl] = useState('');
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [sharedVideos, setSharedVideos] = useState<{url: string, by: string}[]>([]); // mock global feed for demo

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'users2', user.uid, 'friends'));
    const unsubscribe = onSnapshot(q, async (snap) => {
      const loaded: { id: string, friend: UserProfile }[] = [];
      for (const d of snap.docs) {
        const friendSnap = await getDocs(query(collection(db, 'users2'), where('__name__', '==', d.data().friendId)));
        if (!friendSnap.empty) {
          loaded.push({ id: d.id, friend: { id: friendSnap.docs[0].id, ...friendSnap.docs[0].data() } as UserProfile });
        }
      }
      setFriends(loaded);
      setLoading(false);
    });
    return () => unsubscribe();
  }, [user]);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !addId.trim()) return;
    try {
      const targetUser = await getDocs(query(collection(db, 'users2'), where('__name__', '==', addId)));
      if (targetUser.empty) {
        alert('User not found!');
        return;
      }
      
      const newFriendId = `f_${addId}`;
      await setDoc(doc(db, 'users2', user.uid, 'friends', newFriendId), {
        friendId: addId,
        status: 'accepted',
        createdAt: Date.now()
      });
      
      const newFriendIdB = `f_${user.uid}`;
      await setDoc(doc(db, 'users2', addId, 'friends', newFriendIdB), {
        friendId: user.uid,
        status: 'accepted',
        createdAt: Date.now()
      });
      
      setAddId('');
    } catch (err) {
      console.error(err);
      alert('Failed to add friend');
    }
  };

  const handleRemove = async (docId: string, friendId: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'users2', user.uid, 'friends', docId));
      await deleteDoc(doc(db, 'users2', friendId, 'friends', `f_${user.uid}`));
    } catch (e) {
      console.error(e);
    }
  };

  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingVideo(true);
    try {
      const url = await uploadVideoToCatbox(file);
      setVideoUrl(url);
      setSharedVideos(prev => [{ url, by: profile?.displayName || 'Unknown' }, ...prev]);
    } catch (err) {
       console.error(err);
       alert("Video upload failed. Catbox may have CORS restrictions or the file is too large.");
    }
    setUploadingVideo(false);
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      <section>
        <header className="mb-6">
          <h1 className="text-3xl font-black tracking-tight mb-2 flex items-center gap-3">
            <Users className="text-green-400" /> Friends
          </h1>
          <p className="text-slate-400">Add friends by their ID to trade and chat. Your ID: <span className="font-mono text-white bg-slate-800 px-2 py-1 rounded">{user?.uid}</span></p>
        </header>

        <form onSubmit={handleAdd} className="flex items-center gap-2 mb-8 max-w-md">
          <input 
            type="text" 
            placeholder="Paste friend's ID here"
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 focus:outline-none focus:border-green-500 transition-colors text-white font-mono text-sm"
            value={addId}
            onChange={e => setAddId(e.target.value)}
          />
          <button 
            type="submit" 
            disabled={!addId.trim()}
            className="bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded-xl font-medium transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            <UserPlus size={18} /> Add
          </button>
        </form>

        {loading ? (
           <div className="flex justify-center p-8"><Loader2 className="animate-spin text-slate-500" /></div>
        ) : friends.length === 0 ? (
          <div className="bg-slate-800/50 rounded-2xl border border-slate-700 p-8 text-center text-slate-500">
            You don't have any friends yet. Share your ID!
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {friends.map(f => (
              
                            <div key={f.id} className="bg-slate-800 rounded-xl p-4 border border-slate-700 flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img src={f.friend.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${f.friend.displayName}`} className="w-10 h-10 rounded-full bg-slate-700" />
                    <div>
                      <div className="font-bold flex items-center gap-2">
  {f.friend.displayName}
  {f.friend.email === 'miguelrafaelmontana@gmail.com' && (
    <span className="bg-red-500/20 text-red-400 text-[10px] px-1.5 py-0.5 rounded border border-red-500/50 flex items-center gap-1">
      <Shield size={10} /> ADMIN
    </span>
  )}
</div>
                      <div className="text-xs text-slate-400">Rank {f.friend.rank || 0}</div>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                   <button onClick={() => setChattingWith({id: f.friend.id, name: f.friend.displayName})} className="flex-1 bg-blue-600 hover:bg-blue-500 text-white py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-colors">
                     <MessageCircle size={16} /> Chat
                   </button>
                   <button onClick={() => handleRemove(f.id, f.friend.id)} className="px-3 bg-slate-700 hover:bg-red-500/20 text-slate-400 hover:text-red-400 transition-colors text-xs font-bold rounded-lg border border-slate-600 hover:border-red-500/50">
                     Remove
                   </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section>
         <header className="mb-6 flex items-center justify-between">
          <h2 className="text-2xl font-black tracking-tight flex items-center gap-3">
            <Video className="text-purple-400" /> Shared Media
          </h2>
          <label className="bg-purple-600 hover:bg-purple-500 cursor-pointer text-white px-4 py-2 rounded-xl font-medium transition-colors flex items-center gap-2">
            {uploadingVideo ? <Loader2 size={18} className="animate-spin" /> : <UploadCloud size={18} />}
            Upload Video (Catbox)
            <input type="file" accept="video/*" className="hidden" onChange={handleVideoUpload} disabled={uploadingVideo} />
          </label>
        </header>
        
        {sharedVideos.length === 0 ? (
          <div className="bg-slate-800/50 rounded-2xl border border-slate-700 border-dashed p-12 text-center text-slate-500">
            Upload gameplay clips to share with friends. Up to 200MB!
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {sharedVideos.map((v, i) => (
               <div key={i} className="bg-slate-900 rounded-2xl overflow-hidden border border-slate-700">
                 <video src={v.url} controls className="w-full aspect-video bg-black" />
                 <div className="p-4 flex items-center gap-2 text-sm text-slate-400">
                   Shared by <span className="font-bold text-white">{v.by}</span>
                 </div>
               </div>
            ))}
          </div>
        )}
      </section>
    
      {chattingWith && user && (
        <ChatModal 
          userUid={user.uid} 
          friendId={chattingWith.id} 
          friendName={chattingWith.name} 
          onClose={() => setChattingWith(null)} 
        />
      )}
    </div>
  );
}
