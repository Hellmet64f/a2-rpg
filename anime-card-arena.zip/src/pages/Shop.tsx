import { useState, useEffect } from 'react';
import { useAuth } from '../lib/useAuth';

import { db } from '../lib/firebase';
import { doc, setDoc, updateDoc, getDoc, getDocs, collection, query, writeBatch } from 'firebase/firestore';
import { PackageOpen, Coins, Loader2, Clock, Info, Sparkles, Star } from 'lucide-react';
import { Card } from '../types';
import AnimeCard from '../components/AnimeCard';
import PackInfoModal from '../components/PackInfoModal';

export default function Shop() {
  const { user, profile } = useAuth();
  const [packs, setPacks] = useState<{name: string, imageURL: string | null}[]>([]);
  const [opening, setOpening] = useState<string | null>(null);
  const [newCards, setNewCards] = useState<Card[] | null>(null);
  const [timeLeft, setTimeLeft] = useState('');
  const [infoAnime, setInfoAnime] = useState<string | null>(null);

  useEffect(() => {
    const fetchPacks = async () => {
      try {
        const res = await fetch('/api/shop/packs');
        const data = await res.json();
        if (data.packs) setPacks(data.packs);
      } catch (err) {
        console.error(err);
      }
    };
    fetchPacks();
    
    const calculateTimeLeft = () => {
      const now = new Date();
      // 5-hour boundary
      const msIn5H = 5 * 60 * 60 * 1000;
      const nextBoundary = Math.ceil(now.getTime() / msIn5H) * msIn5H;
      const diff = nextBoundary - now.getTime();
      
      const h = Math.floor(diff / (1000 * 60 * 60));
      const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const s = Math.floor((diff % (1000 * 60)) / 1000);
      
      setTimeLeft(`${h}h ${m}m ${s}s`);
    };

    calculateTimeLeft();
    const interval = setInterval(() => {
      calculateTimeLeft();
      if (new Date().getMinutes() === 0 && new Date().getSeconds() === 0) fetchPacks(); // fetch periodically
    }, 1000);
    
    return () => clearInterval(interval);
  }, []);

  const handleBuyPack = async (anime: string, quantity: number = 1) => {
    if (!user || !profile) return;
    const cost = 100 * quantity;
    if ((profile.points || 0) < cost) {
      alert(`You need ${cost} points to buy ${quantity} pack(s).`);
      return;
    }
    
    // Anti-bot basic client check
    const lastOpen = parseInt(localStorage.getItem('lastPackOpen') || '0');
    if (Date.now() - lastOpen < 1000) {
      alert("Opening packs too fast! Please wait a moment.");
      return;
    }
    localStorage.setItem('lastPackOpen', Date.now().toString());
    setOpening(anime);
    
    try {
      const q = query(collection(db, 'users2', user.uid, 'cards2'));
      const snap = await getDocs(q);
      
      const userCardsMap = new Map();
      
      for (const d of snap.docs) {
        const c = d.data();
        if (c.cardName) {
           userCardsMap.set(c.cardName, { id: d.id, cardId: c.cardId, level: c.level || 1 });
        } else {
           const globalCardSnap = await getDoc(doc(db, 'cards2', c.cardId));
           if (globalCardSnap.exists()) {
             userCardsMap.set(globalCardSnap.data().name, { id: d.id, cardId: c.cardId, level: c.level || 1 });
           }
        }
      }

      // Fetch cards FIRST before deducting points to avoid losing points on network failure or navigation
      const fetchPromise = fetch('/api/shop/open', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ anime, quantity })
      });
      const timerPromise = new Promise(r => setTimeout(r, 2000));
      const [res] = await Promise.all([fetchPromise, timerPromise]);
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      
      // Verify points again right before batch commit
      const userRef = doc(db, 'users2', user.uid);
      const userDoc = await getDoc(userRef);
      const currentPoints = userDoc.data()?.points || 0;
      if (currentPoints < cost) {
         throw new Error("Not enough points!");
      }

      // We need writeBatch from firestore
      const { writeBatch } = await import('firebase/firestore');
      const batch = writeBatch(db);
      
      batch.update(userRef, { points: currentPoints - cost });

      const pulledCards = [];
      for(let i=0; i<quantity; i++) {
         const cardData = data.cards[i];
         
         // Enforce types and casing to pass Firestore strict rules
         const cleanCardData = {
           name: String(cardData.name || 'Unknown'),
           anime: String(cardData.anime || anime),
           power: Number(cardData.power || 10),
           resistance: Number(cardData.resistance || 10),
           rarity: String(cardData.rarity || 'common').toLowerCase(),
           imageURL: String(cardData.imageURL || 'https://api.dicebear.com/7.x/pixel-art/svg?seed=fallback')
         };
         if (cardData.isShiny !== undefined) cleanCardData.isShiny = Boolean(cardData.isShiny);
         if (cardData.searchQuery !== undefined) cleanCardData.searchQuery = String(cardData.searchQuery);

         if (userCardsMap.has(cleanCardData.name)) {
            const existing = userCardsMap.get(cleanCardData.name);
            const newLevel = existing.level + 1;
            batch.update(doc(db, 'users2', user.uid, 'cards2', existing.id), {
              level: newLevel,
              cardName: cleanCardData.name
            });
            existing.level = newLevel; 
            pulledCards.push({ id: existing.cardId, ...cleanCardData, level: newLevel } as any);
         } else {
            const newCardId = `card_${Date.now()}_${i}_${Math.random().toString(36).substring(2)}`;
            batch.set(doc(db, 'cards2', newCardId), { ...cleanCardData, createdAt: Date.now() });
            
            const userCardId = `uc_${Date.now()}_${i}`;
            batch.set(doc(db, 'users2', user.uid, 'cards2', userCardId), {
              cardId: newCardId,
              cardName: cleanCardData.name,
              acquiredAt: Date.now(),
              level: 1
            });
            userCardsMap.set(cleanCardData.name, { id: userCardId, cardId: newCardId, level: 1 });
            pulledCards.push({ id: newCardId, ...cleanCardData, level: 1 } as any);
         }
      }
      
      await batch.commit();
      
      setNewCards(pulledCards);
    } catch (err) {
      console.error(err);
      alert("Failed to open pack: " + err.message);
    }
    setOpening(null);
  };
  
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">Shop & Packs</h1>
          <p className="text-slate-400 flex items-center gap-2">
            <Clock size={16} className="text-blue-400" />
            Packs update globally in <span className="text-white font-mono font-bold">{timeLeft}</span>
          </p>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 flex items-center gap-2">
           <Coins className="text-yellow-400" size={18} />
           <span className="font-bold">{profile?.points || 0} pts</span>
        </div>
      </header>
      <div className="bg-blue-900/40 text-blue-300 p-4 rounded-xl border border-blue-800 flex items-start gap-3">
        <Info className="shrink-0 mt-0.5" />
        <p className="text-sm">
          <strong>Did you know?</strong> Every card has unique base stats! Even if you pull the same character, their Power and Resistance might vary based on RNG. Plus, there is a rare <strong>⭐ 5% chance</strong> to pull a <strong>Shiny</strong> character with 50% more stats! Characters pulled are random entities from their anime's cast.
        </p>
      </div>

      {opening && !newCards && (
        <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-black/95 backdrop-blur-md animate-in fade-in duration-300 px-4"> 
           <div className="animate-bounce-slow flex flex-col items-center relative">
             <div className="absolute inset-0 bg-yellow-500/20 blur-[100px] rounded-full animate-pulse"></div>
             <PackageOpen size={120} className="text-yellow-400 drop-shadow-[0_0_30px_rgba(250,204,21,0.6)] relative z-10" />
             <h2 className="text-3xl font-black text-white mt-8 animate-pulse text-center relative z-10">Opening {opening} Pack...</h2>
           </div>
        </div>
      )}

      {newCards && newCards.length > 0 && (
        <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-black/95 backdrop-blur-xl animate-in fade-in duration-500 px-4 overflow-y-auto py-12"> 
           <div className="absolute inset-0 overflow-hidden pointer-events-none fixed">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-yellow-500/20 blur-[120px] rounded-full mix-blend-screen animate-pulse"></div>
           </div>
           
           <div className="flex flex-col items-center max-w-6xl w-full relative z-10 mt-auto pt-24 pb-12">
             <div className="flex items-center justify-center gap-3 mb-8 animate-in slide-in-from-bottom-8 duration-700 delay-150 fill-mode-both">
               <h2 className="text-4xl md:text-5xl font-black text-center text-transparent bg-clip-text bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 drop-shadow-[0_0_30px_rgba(250,204,21,0.8)]">
                 {newCards.length > 1 ? `${newCards.length} CARDS UNLOCKED!` : (newCards[0].isShiny ? 'SHINY!' : (newCards[0].level && newCards[0].level > 1 ? 'LEVEL UP!' : 'UNLOCKED!'))}
               </h2>
             </div>
             
             <div className="flex flex-wrap items-center justify-center gap-6 mb-10 w-full animate-in zoom-in-95 duration-700">
               {newCards.map((card, idx) => (
                 <div key={idx} className="w-48 md:w-56 pointer-events-none hover:scale-105 transition-transform relative animate-in zoom-in-50 duration-700 fill-mode-both" style={{ animationDelay: `${idx * 100 + 200}ms` }}>
                   {card.isShiny && (
                      <div className="absolute -top-4 -right-4 z-20 animate-spin-slow">
                        <Sparkles className="text-yellow-400 w-8 h-8 drop-shadow-lg" />
                      </div>
                   )}
                   {card.level && card.level > 1 && (
                      <div className="absolute -top-3 -left-3 z-20 bg-blue-600 text-white text-xs font-black px-2 py-1 rounded-lg border-2 border-slate-900 shadow-xl rotate-[-10deg]">
                        LVL {card.level}
                      </div>
                   )}
                   <AnimeCard card={card} className="w-full shadow-[0_0_30px_rgba(250,204,21,0.3)]" />
                 </div>
               ))}
             </div>
             
             <button 
               onClick={() => setNewCards(null)}
               className="bg-white text-slate-900 w-full max-w-xs py-4 rounded-xl font-black text-2xl transition-all hover:scale-110 active:scale-95 shadow-[0_0_40px_rgba(255,255,255,0.5)] hover:shadow-[0_0_60px_rgba(255,255,255,0.8)] mb-auto mt-4"
             >
               CLAIM
             </button>
           </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {packs.map(pack => (
          <div key={pack.name} className="bg-slate-800 rounded-3xl border border-slate-700 overflow-hidden group hover:-translate-y-2 transition-all hover:shadow-[0_0_30px_rgba(59,130,246,0.2)] flex flex-col">
            <div className="h-40 bg-gradient-to-br from-indigo-500/20 to-purple-500/20 flex items-center justify-center relative overflow-hidden shrink-0">
               {pack.imageURL ? (
                  <img src={pack.imageURL} alt={pack.name} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500" />
               ) : (
                  <PackageOpen size={48} className="text-indigo-400 opacity-50 group-hover:scale-125 group-hover:opacity-100 transition-all duration-500" />
               )}
               <div className="absolute inset-0 bg-gradient-to-t from-slate-800 to-transparent"></div>
            </div>
            
            <div className="p-6 flex flex-col flex-1 relative z-10">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-black text-xl line-clamp-1">{pack.name} Pack</h3>
                <button 
                  onClick={() => setInfoAnime(pack.name)}
                  className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-full transition-colors"
                  title="View Pack Info"
                >
                  <Info size={16} />
                </button>
              </div>
              <p className="text-sm text-slate-400 mb-6 flex-1">Contains character from {pack.name} cast. Duplicates level up your card!</p>
              
              <div className="flex gap-2 w-full mt-auto">
                <button 
                  onClick={() => handleBuyPack(pack.name, 1)}
                  disabled={opening !== null}
                  className="flex-1 flex items-center justify-center gap-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white py-2 rounded-xl font-bold transition-all disabled:opacity-50 text-sm shadow-md"
                >
                  {opening === pack.name ? <Loader2 className="animate-spin" /> : <><Coins size={14} /> 1x (100)</>}
                </button>
                <button 
                  onClick={() => handleBuyPack(pack.name, 10)}
                  disabled={opening !== null}
                  className="flex-1 flex items-center justify-center gap-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white py-2 rounded-xl font-bold transition-all disabled:opacity-50 text-sm shadow-md"
                >
                  {opening === pack.name ? <Loader2 className="animate-spin" /> : <><PackageOpen size={14} /> 10x (1000)</>}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      <PackInfoModal anime={infoAnime} onClose={() => setInfoAnime(null)} />
    </div>
  );
}
