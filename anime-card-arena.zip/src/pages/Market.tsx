import { useState, useEffect } from 'react';
import { useAuth } from '../lib/useAuth';
import { db } from '../lib/firebase';
import { collection, query, getDocs, doc, setDoc, getDoc, updateDoc, deleteDoc, where } from 'firebase/firestore';
import { Loader2, Coins, Tag } from 'lucide-react';
import { Card, MarketListing, UserProfile } from '../types';
import AnimeCard from '../components/AnimeCard';
import BuyModal from '../components/BuyModal';

export default function Market() {
  const { user, profile } = useAuth();
  const [listings, setListings] = useState<(MarketListing & { cardData: Card, seller: UserProfile })[]>([]);
  const [loading, setLoading] = useState(true);
  const [buyingListing, setBuyingListing] = useState<(MarketListing & { cardData: Card, seller: UserProfile }) | null>(null);

  useEffect(() => {
    fetchMarket();
  }, [user]);

  
  const fetchMarket = async () => {
    setLoading(true);
    try {
      const q = query(collection(db, 'market2'), where('status', '==', 'open'));
      const snap = await getDocs(q);
      
      const loadedListings: (MarketListing & { cardData: Card, seller: UserProfile })[] = [];
      for (const d of snap.docs) {
        const listing = { id: d.id, ...d.data() } as MarketListing;
        const [cardSnap, sellerSnap] = await Promise.all([
          getDoc(doc(db, 'cards2', listing.userCardId)), // userCardId now stores the global cardId
          getDoc(doc(db, 'users2', listing.sellerId))
        ]);
        
        if (cardSnap.exists() && sellerSnap.exists()) {
          loadedListings.push({ 
             ...listing,
             cardData: { id: cardSnap.id, ...cardSnap.data() } as Card,
             seller: { id: sellerSnap.id, ...sellerSnap.data() } as UserProfile
          });
        }
      }
      setListings(loadedListings);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  
  
  
  
  
  const handleBuy = async (listing: MarketListing) => {
    // Anti-bot check
    const lastBuy = parseInt(localStorage.getItem('lastMarketBuy') || '0');
    if (Date.now() - lastBuy < 1000) {
      alert("Buying too fast! Slow down.");
      return;
    }
    localStorage.setItem('lastMarketBuy', Date.now().toString());
    if (!user || !profile) return;
    try {
      // Use writeBatch for atomic transaction
      const { writeBatch } = await import('firebase/firestore');
      const batch = writeBatch(db);

      // 1. Update listing status
      batch.update(doc(db, 'market2', listing.id), { status: 'sold' });
      
      // 2. Deduct points from buyer
      batch.update(doc(db, 'users2', user.uid), {
        points: (profile.points || 0) - listing.price
      });

      // 3. Add points to seller
      const sellerProfileSnap = await getDoc(doc(db, 'users2', listing.sellerId));
      if (sellerProfileSnap.exists()) {
         batch.update(doc(db, 'users2', listing.sellerId), {
           points: (sellerProfileSnap.data().points || 0) + listing.price
         });
      }

      // 4. Move card to buyer
      const newUserCardId = `uc_${Date.now()}`;
      batch.set(doc(db, 'users2', user.uid, 'cards2', newUserCardId), {
        cardId: listing.userCardId,
        acquiredAt: Date.now()
      });

      await batch.commit();

      // Refresh
      await fetchMarket();
    } catch (err) {
       console.error("Buy error:", err);
       alert("Transaction failed: " + (err as any).message);
    }
  };


  const handleCancel = async (listing: MarketListing) => {
    if (!user || listing.sellerId !== user.uid) return;
    if (!confirm("Are you sure you want to cancel this listing and return the card to your collection?")) return;
    try {
      await updateDoc(doc(db, 'market2', listing.id), { status: 'cancelled' });
      
      const userCardId = `uc_${Date.now()}`;
      await setDoc(doc(db, 'users2', user.uid, 'cards2', userCardId), {
        cardId: listing.userCardId,
        acquiredAt: Date.now()
      });
      
      await fetchMarket();
    } catch (e) {
      console.error(e);
      alert("Failed to cancel listing.");
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">Global Market</h1>
          <p className="text-slate-400">Trade rare cards with other players.</p>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 flex items-center gap-2">
           <Coins className="text-yellow-400" size={18} />
           <span className="font-bold">{profile?.points || 0} pts</span>
        </div>
      </header>

      {loading ? (
        <div className="flex justify-center p-12"><Loader2 className="animate-spin text-slate-500" size={32} /></div>
      ) : listings.length === 0 ? (
        <div className="text-center p-16 bg-slate-800/50 rounded-3xl border border-slate-700 border-dashed">
          <p className="text-slate-400">The market is currently empty.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {listings.map(l => (
            <div key={l.id} className="relative flex flex-col group">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-20 bg-slate-800 px-3 py-1 rounded-full border border-slate-600 flex items-center gap-2 shadow-lg">
                <img src={l.seller.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${l.seller.displayName}`} className="w-5 h-5 rounded-full" />
                <span className="text-xs text-slate-300 font-medium truncate max-w-[80px]">{l.seller.displayName}</span>
              </div>
              <AnimeCard card={l.cardData} className="flex-1" />
              
              {l.sellerId === user?.uid ? (
                <button 
                  onClick={() => handleCancel(l)}
                  className="mt-4 w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 text-white py-3 rounded-xl font-black transition-colors shadow-lg border border-red-500/50"
                >
                  <Tag size={16} />
                  CANCEL
                </button>
              ) : (
                <button 
                  onClick={() => setBuyingListing(l)}
                  disabled={l.sellerId === user?.uid}
                  className="mt-4 w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white py-3 rounded-xl font-black transition-colors shadow-lg border border-blue-500/50 disabled:border-slate-700"
                >
                  <Tag size={16} />
                  {l.price} PTS
                </button>
              )}

            </div>
          ))}
        </div>
      )}
    
      <BuyModal 
        listing={buyingListing}
        onClose={() => setBuyingListing(null)}
        onBuy={handleBuy}
        userPoints={profile?.points || 0}
      />
    </div>
  );
}
