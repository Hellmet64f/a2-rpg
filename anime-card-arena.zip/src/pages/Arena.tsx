import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/useAuth';
import { db } from '../lib/firebase';
import { collection, query, getDocs, doc, setDoc, updateDoc, onSnapshot, where, deleteDoc, getDoc } from 'firebase/firestore';
import { Loader2, Swords, Trophy, Skull } from 'lucide-react';
import { Battle, UserProfile, Card, UserCard } from '../types';
import AnimeCard from '../components/AnimeCard';

export default function Arena() {
  const { user, profile } = useAuth();
  const [activeBattle, setActiveBattle] = useState<Battle | null>(null);
  const [searching, setSearching] = useState(false);
  const [opponent, setOpponent] = useState<UserProfile | null>(null);
  
  const [myCards, setMyCards] = useState<(UserCard & { cardData: Card })[]>([]);
  const [selectedCard, setSelectedCard] = useState<Card | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchCards = async () => {
      try {
        const q = query(collection(db, 'users2', user.uid, 'cards2'));
        const snap = await getDocs(q);
        const loaded: (UserCard & { cardData: Card })[] = [];
        for (const d of snap.docs) {
          const uCard = { id: d.id, ...d.data() } as UserCard;
          const cSnap = await getDoc(doc(db, 'cards2', uCard.cardId));
          if (cSnap.exists()) {
            loaded.push({ ...uCard, cardData: { id: cSnap.id, ...cSnap.data() } as Card });
          }
        }
        loaded.sort((a, b) => b.cardData.power - a.cardData.power);
        setMyCards(loaded);
        if (loaded.length > 0) setSelectedCard(loaded[0].cardData);
      } catch (err) {
        console.error(err);
      }
      setLoading(false);
    };
    fetchCards();
  }, [user]);

  useEffect(() => {
    if (!user) return;
    
    // Listen for my active battles
    const q1 = query(collection(db, 'battles2'), where('player1Id', '==', user.uid), where('status', 'in', ['waiting', 'playing', 'finished']));
    const q2 = query(collection(db, 'battles2'), where('player2Id', '==', user.uid), where('status', 'in', ['waiting', 'playing', 'finished']));

    const unsubscribe1 = onSnapshot(q1, (snap) => {
      if (!snap.empty) {
        setActiveBattle({ id: snap.docs[0].id, ...snap.docs[0].data() } as Battle);
      }
    });

    const unsubscribe2 = onSnapshot(q2, (snap) => {
      if (!snap.empty && !activeBattle) {
        setActiveBattle({ id: snap.docs[0].id, ...snap.docs[0].data() } as Battle);
      }
    });

    return () => {
      unsubscribe1();
      unsubscribe2();
    };
  }, [user]);

  useEffect(() => {
    if (activeBattle) {
      const oppId = activeBattle.player1Id === user?.uid ? activeBattle.player2Id : activeBattle.player1Id;
      if (oppId) {
        getDocs(query(collection(db, 'users2'), where('__name__', '==', oppId))).then(snap => {
           if(!snap.empty) setOpponent({ id: snap.docs[0].id, ...snap.docs[0].data() } as UserProfile);
        });
      } else {
        setOpponent(null);
      }
      
      // Auto battle if we are Player 1 and status is playing
      if (activeBattle.status === 'playing' && activeBattle.player1Id === user?.uid) {
         if (!activeBattle.winnerId) { // Prevent re-running
           setTimeout(() => autoResolveBattle(activeBattle), 2000);
         }
      }
    }
  }, [activeBattle, user]);

  const autoResolveBattle = async (battle: Battle) => {
     // A very simple immediate auto-resolve by the host (Player 1)
     const won = Math.random() > 0.5; // Since we don't have P2's card stored easily, just 50/50 mock for now
     
     await updateDoc(doc(db, 'battles2', battle.id), {
       status: 'finished',
       winnerId: won ? battle.player1Id : (battle.player2Id || ''),
       state: won ? 'Player 1 dominates the battle!' : 'Player 2 counters perfectly and wins!',
       updatedAt: Date.now()
     });
     
     // Reward points to winner
     if (won && user) {
       await updateDoc(doc(db, 'users2', user.uid), {
         points: (profile?.points || 0) + 100
       });
     }
  };

  const findMatch = async () => {
    if (!user || !selectedCard || searching) return;
    const lastFind = parseInt(localStorage.getItem('lastFindMatch') || '0');
    if (Date.now() - lastFind < 1500) {
      alert("Please wait before searching again.");
      return;
    }
    localStorage.setItem('lastFindMatch', Date.now().toString());
    setSearching(true);
    try {
      // Find waiting matches
      const q = query(collection(db, 'battles2'), where('status', '==', 'waiting'));
      const snap = await getDocs(q);
      
      const available = snap.docs.filter(d => d.data().player1Id !== user.uid);
      
      if (available.length > 0) {
        // Join first available
        await updateDoc(doc(db, 'battles2', available[0].id), {
          player2Id: user.uid,
          status: 'playing',
          updatedAt: Date.now(),
          state: 'Battle Started! Auto-resolving...'
        });
      } else {
        // Create new
        const battleId = `b_${Date.now()}`;
        await setDoc(doc(db, 'battles2', battleId), {
          player1Id: user.uid,
          status: 'waiting',
          createdAt: Date.now(),
          updatedAt: Date.now(),
          state: 'Waiting...'
        });
      }
    } catch (err) {
      console.error(err);
      setSearching(false);
    }
  };

  const cancelSearch = async () => {
    if (activeBattle && activeBattle.status === 'waiting' && activeBattle.player1Id === user?.uid) {
       await deleteDoc(doc(db, 'battles2', activeBattle.id));
       setActiveBattle(null);
       setSearching(false);
    } else {
       setActiveBattle(null);
       setSearching(false);
    }
  };

  if (loading) {
     return <div className="flex justify-center p-12"><Loader2 className="animate-spin text-slate-500" size={32} /></div>;
  }

  if (!activeBattle) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-6 animate-in fade-in zoom-in-95 duration-500">
        <div className="bg-red-500/10 p-6 rounded-full border border-red-500/20">
          <Swords size={64} className="text-red-500" />
        </div>
        <h1 className="text-4xl font-black">Global Arena</h1>
        
        {myCards.length === 0 ? (
          <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700 text-slate-400 max-w-sm text-center">
            You don't have any cards yet. Go to the Shop to open packs before entering the Arena.
          </div>
        ) : (
          <div className="flex flex-col items-center gap-8 w-full">
            <p className="text-slate-400 text-center max-w-md">Select your champion and enter the queue.</p>
            
            <div className="bg-slate-900/80 backdrop-blur p-8 rounded-3xl border border-slate-700 w-full max-w-4xl shadow-2xl">
              <h2 className="text-2xl font-black mb-6 text-center">Select your Fighter</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 max-h-[400px] overflow-y-auto p-2">
                {myCards.map(c => (
                  <AnimeCard 
                    key={c.id} 
                    card={c.cardData} 
                    selected={selectedCard?.id === c.cardData.id}
                    onClick={() => setSelectedCard(c.cardData)}
                    className={selectedCard && selectedCard.id !== c.cardData.id ? 'opacity-40 grayscale hover:grayscale-0 hover:opacity-100' : ''}
                  />
                ))}
              </div>
            </div>

            <button 
              onClick={findMatch}
              disabled={searching || !selectedCard}
              className="bg-red-600 hover:bg-red-500 disabled:bg-slate-700 text-white px-12 py-5 rounded-full font-black text-xl transition-all shadow-[0_0_40px_rgba(220,38,38,0.4)] hover:shadow-[0_0_60px_rgba(220,38,38,0.6)] flex items-center gap-3 disabled:shadow-none hover:scale-105"
            >
              {searching ? <><Loader2 className="animate-spin" /> Searching...</> : 'Find Match'}
            </button>
          </div>
        )}
      </div>
    );
  }

  if (activeBattle.status === 'waiting') {
     return (
       <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-6">
         <div className="relative">
           <div className="absolute inset-0 bg-blue-500 blur-xl opacity-30 animate-pulse rounded-full" />
           <Loader2 size={64} className="animate-spin text-blue-500 relative z-10" />
         </div>
         <h2 className="text-3xl font-black">Waiting for opponent...</h2>
         <p className="text-slate-400">Matchmaking in progress across the globe.</p>
         <button onClick={cancelSearch} className="text-slate-300 hover:text-white transition-colors bg-slate-800 hover:bg-slate-700 px-8 py-3 rounded-full border border-slate-700 font-bold mt-4">Cancel Search</button>
       </div>
     )
  }

  const isFinished = activeBattle.status === 'finished';
  const iWon = activeBattle.winnerId === user?.uid;

  return (
    <div className="max-w-5xl mx-auto animate-in fade-in duration-500">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500 mb-2 drop-shadow-md">GLOBAL ARENA</h1>
        <p className="text-slate-400 font-mono text-sm bg-slate-900 inline-block px-4 py-2 rounded-full border border-slate-800">{activeBattle.state}</p>
      </header>

      <div className="relative flex flex-col md:flex-row items-center justify-between gap-12 bg-slate-900/90 backdrop-blur-xl p-12 rounded-[3rem] border border-slate-700 shadow-2xl overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-800/50 via-slate-900 to-slate-900 pointer-events-none" />
        
        {/* Player 1 (Me) */}
        <div className={`flex flex-col items-center gap-6 z-10 transition-all duration-700 ${isFinished && iWon ? 'scale-110' : isFinished && !iWon ? 'opacity-50 grayscale scale-90' : ''}`}>
          <div className="relative">
            {isFinished && iWon && <div className="absolute inset-0 bg-yellow-400 blur-2xl opacity-50 rounded-full animate-pulse" />}
            <img src={profile?.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.displayName}`} className="w-32 h-32 rounded-full border-4 border-blue-500 object-cover relative z-10 shadow-2xl bg-slate-800" />
          </div>
          <div className="text-center bg-slate-950/50 px-6 py-2 rounded-2xl border border-slate-800 backdrop-blur-sm">
            <h3 className="font-black text-2xl">{profile?.displayName}</h3>
            <span className="text-blue-400 text-sm font-bold uppercase">You</span>
          </div>
        </div>

        {/* VS */}
        <div className="flex flex-col items-center z-10">
           <div className="w-24 h-24 bg-slate-950 rounded-full flex items-center justify-center border-4 border-slate-800 shadow-[0_0_30px_rgba(0,0,0,0.5)] z-20">
             <span className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-br from-slate-300 to-slate-500 italic">VS</span>
           </div>
           {!isFinished && <Loader2 className="animate-spin text-red-500 mt-6 drop-shadow-[0_0_15px_rgba(239,68,68,0.8)]" size={32} />}
        </div>

        {/* Player 2 (Opponent) */}
        <div className={`flex flex-col items-center gap-6 z-10 transition-all duration-700 ${isFinished && !iWon ? 'scale-110' : isFinished && iWon ? 'opacity-50 grayscale scale-90' : ''}`}>
          <div className="relative">
            {isFinished && !iWon && <div className="absolute inset-0 bg-yellow-400 blur-2xl opacity-50 rounded-full animate-pulse" />}
            <img src={opponent?.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${opponent?.displayName}`} className="w-32 h-32 rounded-full border-4 border-red-500 object-cover relative z-10 shadow-2xl bg-slate-800" />
          </div>
          <div className="text-center bg-slate-950/50 px-6 py-2 rounded-2xl border border-slate-800 backdrop-blur-sm">
            <h3 className="font-black text-2xl">{opponent?.displayName || 'Opponent'}</h3>
            <span className="text-red-400 text-sm font-bold uppercase">Enemy</span>
          </div>
        </div>
      </div>

      <div className="mt-12 flex justify-center">
        {isFinished && (
          <div className="flex flex-col items-center gap-8 animate-in zoom-in duration-500 bg-slate-900/80 backdrop-blur p-12 rounded-[3rem] border border-slate-700 shadow-2xl w-full max-w-2xl">
            <div className={`text-5xl font-black flex items-center gap-4 ${iWon ? 'text-yellow-400 drop-shadow-[0_0_20px_rgba(250,204,21,0.5)]' : 'text-slate-500'}`}>
              {iWon ? <><Trophy size={64} /> VICTORY! (+100 Pts)</> : <><Skull size={64} /> DEFEAT</>}
            </div>
            <button 
              onClick={cancelSearch}
              className="bg-white hover:bg-slate-200 text-slate-900 px-12 py-4 rounded-xl transition-colors font-black text-xl shadow-[0_0_30px_rgba(255,255,255,0.2)] hover:scale-105 active:scale-95"
            >
              LEAVE ARENA
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
