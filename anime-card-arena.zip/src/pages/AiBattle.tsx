import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/useAuth';
import { db } from '../lib/firebase';
import { collection, query, getDocs, doc, updateDoc, getDoc } from 'firebase/firestore';
import { Swords, Trophy, Skull, Bot, Loader2, Zap } from 'lucide-react';
import { robo1 } from '../lib/robot';
import { Card, UserCard } from '../types';
import AnimeCard from '../components/AnimeCard';

export default function AiBattle() {
  const { user, profile } = useAuth();
  const [battleState, setBattleState] = useState<'idle' | 'playing' | 'won' | 'lost'>('idle');
  const [enemy, setEnemy] = useState<any>(null);
  const [myCards, setMyCards] = useState<(UserCard & { cardData: Card })[]>([]);
  const [selectedCard, setSelectedCard] = useState<Card | null>(null);
  const [loading, setLoading] = useState(true);
  const [log, setLog] = useState<string[]>([]);
  const [playerHp, setPlayerHp] = useState(100);
  const [enemyHp, setEnemyHp] = useState(100);
  const [maxPlayerHp, setMaxPlayerHp] = useState(100);
  const [maxEnemyHp, setMaxEnemyHp] = useState(100);
  const [isBattling, setIsBattling] = useState(false);

  useEffect(() => {
    if (!user) return;
    const fetchCards = async () => {
      try {
        const q = query(collection(db, 'users2', user.uid, 'cards2'));
        const snap = await getDocs(q);
        const loaded: (UserCard & { cardData: Card })[] = [];
        for (const d of snap.docs) {
          const uCard = { id: d.id, ...d.data() } as UserCard;
          const cSnap = await getDoc(doc(db, 'cards2', uCard.cardId));
          if (cSnap.exists()) {
            loaded.push({ ...uCard, cardData: { id: cSnap.id, ...cSnap.data() } as Card });
          }
        }
        loaded.sort((a, b) => b.cardData.power - a.cardData.power);
        setMyCards(loaded);
        if (loaded.length > 0) setSelectedCard(loaded[0].cardData);
      } catch (err) {
        console.error(err);
      }
      setLoading(false);
    };
    fetchCards();
  }, [user]);

  const [isStarting, setIsStarting] = useState(false);

  const startAutoBattle = async () => {
    if (!selectedCard || !profile || !user || isStarting || isBattling) return;
    const lastFind = parseInt(localStorage.getItem('lastAiBattle') || '0');
    if (Date.now() - lastFind < 1500) {
      alert("Please wait before starting another battle.");
      return;
    }
    localStorage.setItem('lastAiBattle', Date.now().toString());
    setIsStarting(true);
    
    // Generate AI
    const seed = Date.now();
    const data = robo1.getAnimeData("Unknown AI", seed);
    const enemyName = robo1.generateCharacterName("AI System", () => Math.random(), data.rarity);
    
    let imageURL = `https://api.dicebear.com/7.x/bottts/svg?seed=${enemyName.replace(/\s+/g, '')}`;
    try {
      const res = await fetch(`https://api.jikan.moe/v4/characters?q=${encodeURIComponent(enemyName)}&limit=1`);
      const json = await res.json();
      if (json.data && json.data.length > 0) {
        imageURL = json.data[0].images.jpg.image_url;
      }
    } catch(e) {}
    
    const aiEnemy = {
      name: enemyName,
      power: data.power,
      resistance: data.resistance,
      image: imageURL
    };
    
    setEnemy(aiEnemy);
    
    let pHp = selectedCard.resistance * 5;
    let eHp = aiEnemy.resistance * 5;
    setMaxPlayerHp(pHp);
    setMaxEnemyHp(eHp);
    
    setPlayerHp(pHp);
    setEnemyHp(eHp);
    setIsStarting(false);
    setBattleState('playing');
    setIsBattling(true);
    setLog([`Battle started: ${selectedCard.name} vs ${aiEnemy.name}`]);

    let currentLogs = [`Battle started: ${selectedCard.name} vs ${aiEnemy.name}`];
    
    const resolveTurn = async () => {
       await new Promise(r => setTimeout(r, 1500));
       if (pHp <= 0 || eHp <= 0) return;
       
       const pDmg = Math.floor(Math.random() * selectedCard.power) + (selectedCard.power * 0.2);
       const eDmg = Math.floor(Math.random() * aiEnemy.power) + (aiEnemy.power * 0.2);
       
       eHp -= pDmg;
       pHp -= eDmg;
       
       setEnemyHp(eHp);
       setPlayerHp(pHp);
       
       currentLogs = [`${aiEnemy.name} hit ${selectedCard.name} for ${Math.floor(eDmg)} damage!`, `${selectedCard.name} hit ${aiEnemy.name} for ${Math.floor(pDmg)} damage!`, ...currentLogs];
       setLog([...currentLogs]);
       
       
       if (eHp <= 0 && pHp > 0) {
         setBattleState('won');
         setIsBattling(false);
         
         
         let currentLevel = profile?.aiLevel || 1;
         let currentWins = (profile?.aiWins || 0) + 1;
         let levelUpMsg = "";
         if (currentWins >= 4) {
           currentLevel += 1;
           currentWins = 0;
           levelUpMsg = ` LEVEL UP! You are now AI Level ${currentLevel}!`;
         }
         
         const reward = 25 + ((currentLevel - 1) * 25);
         
         setLog([`Victory! You earned ${reward} points.${levelUpMsg}`, ...currentLogs]);
         await updateDoc(doc(db, 'users2', user.uid), {
            points: (profile?.points || 0) + reward,
            aiWins: currentWins,
            aiLevel: currentLevel
         });

       } else if (pHp <= 0 && eHp > 0) {

         setBattleState('lost');
         setIsBattling(false);
         setLog(["Defeat. Better luck next time.", ...currentLogs]);
       } else if (pHp <= 0 && eHp <= 0) {
         setBattleState('lost');
         setIsBattling(false);
         setLog(["Draw. No points awarded.", ...currentLogs]);
       } else {
         resolveTurn();
       }
    };
    
    resolveTurn();
  };

  if (loading) {
    return <div className="flex justify-center p-12"><Loader2 className="animate-spin text-slate-500" size={32} /></div>;
  }

  return (
    <div className="max-w-4xl mx-auto animate-in fade-in duration-500">
      <header className="text-center mb-12">
        <h1 className="text-3xl font-black text-blue-500 mb-2 flex items-center justify-center gap-3">
          <Bot /> Training Mode
        </h1>
        <p className="text-slate-400">Battle against the AI to earn points for packs.</p>
        <div className="mt-4 inline-block bg-slate-800 border border-slate-700 px-4 py-2 rounded-xl text-yellow-400 font-bold">
           AI Level: {profile?.aiLevel || 1} ({profile?.aiWins || 0}/4 Wins)
        </div>
      </header>

      {myCards.length === 0 ? (
        <div className="bg-slate-800/50 rounded-2xl p-12 text-center text-slate-400 border border-slate-700">
           You need at least one character card to battle! Go open a pack in the Shop.
        </div>
      ) : battleState === 'idle' ? (
        <div className="flex flex-col items-center gap-8">
           <div className="bg-slate-900/80 backdrop-blur p-8 rounded-3xl border border-slate-700 w-full max-w-4xl shadow-2xl">
             <h2 className="text-2xl font-black mb-6 text-center">Select your Fighter</h2>
             <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 max-h-[400px] overflow-y-auto p-2">
               {myCards.map(c => (
                 <AnimeCard 
                   key={c.id} 
                   card={c.cardData} 
                   selected={selectedCard?.id === c.cardData.id}
                   onClick={() => setSelectedCard(c.cardData)}
                   className={selectedCard && selectedCard.id !== c.cardData.id ? 'opacity-40 grayscale hover:grayscale-0 hover:opacity-100' : ''}
                 />
               ))}
             </div>
           </div>

           <button 
             onClick={startAutoBattle}
             disabled={!selectedCard || isStarting || isBattling}
             className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white px-12 py-5 rounded-full font-black text-xl transition-all shadow-[0_0_40px_rgba(59,130,246,0.4)] hover:shadow-[0_0_60px_rgba(59,130,246,0.6)] flex items-center gap-3 disabled:opacity-50 disabled:shadow-none hover:scale-105"
           >
             {isStarting ? <><Loader2 className="animate-spin" size={28} /> INIT BATTLE...</> : <><Swords size={28} /> INIT BATTLE</>}
           </button>
        </div>
      ) : (
        <div className="space-y-12">
          <div className="relative flex flex-col md:flex-row items-center justify-between gap-12 bg-slate-900/90 backdrop-blur-xl p-8 rounded-[3rem] border border-slate-700 shadow-2xl overflow-hidden">
            {/* Background elements */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-red-900/20 opacity-50" />
            <div className="absolute top-0 left-0 w-1/2 h-full bg-gradient-to-r from-blue-600/10 to-transparent pointer-events-none" />
            <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-red-600/10 to-transparent pointer-events-none" />
            
            {/* Player */}
            <div className="flex flex-col items-center gap-6 w-full md:w-1/3 z-10">
              <div className="w-48">
                <AnimeCard card={selectedCard!} className={isBattling ? "animate-pulse shadow-[0_0_30px_rgba(59,130,246,0.5)]" : ""} />
              </div>
              <div className="w-full bg-slate-950 h-6 rounded-full overflow-hidden border-2 border-slate-700 relative shadow-inner">
                 <div className="bg-gradient-to-r from-blue-600 to-cyan-400 h-full transition-all duration-300" style={{ width: `${Math.max(0, (playerHp / maxPlayerHp) * 100)}%` }}></div>
                 <span className="absolute inset-0 flex items-center justify-center font-mono text-[10px] font-bold tracking-widest text-white drop-shadow-md">{Math.max(0, Math.floor(playerHp))} / {maxPlayerHp} HP</span>
              </div>
            </div>

            {/* VS */}
            <div className="flex flex-col items-center z-10 shrink-0">
              <div className="w-24 h-24 bg-slate-950 rounded-full flex items-center justify-center border-4 border-slate-800 shadow-[0_0_30px_rgba(0,0,0,0.5)] z-20">
                <span className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-br from-slate-300 to-slate-500 italic">VS</span>
              </div>
              {isBattling && <Zap size={32} className="text-yellow-400 animate-bounce mt-6 drop-shadow-[0_0_15px_rgba(250,204,21,0.8)]" />}
            </div>

            {/* AI Enemy */}
            <div className="flex flex-col items-center gap-6 w-full md:w-1/3 z-10">
              <div className="w-48 relative">
                {/* Simulated AI Card wrapper since enemy is not of type Card fully, but we can map it to match AnimeCard props closely */}
                <AnimeCard card={{ ...enemy, rarity: 'common', anime: 'AI System' } as Card} className={isBattling ? "animate-pulse shadow-[0_0_30px_rgba(239,68,68,0.5)]" : ""} />
              </div>
              <div className="w-full bg-slate-950 h-6 rounded-full overflow-hidden border-2 border-slate-700 relative shadow-inner">
                 <div className="bg-gradient-to-l from-red-600 to-orange-400 h-full transition-all duration-300" style={{ width: `${Math.max(0, (enemyHp / maxEnemyHp) * 100)}%` }}></div>
                 <span className="absolute inset-0 flex items-center justify-center font-mono text-[10px] font-bold tracking-widest text-white drop-shadow-md">{Math.max(0, Math.floor(enemyHp))} / {maxEnemyHp} HP</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-center gap-8">
            {!isBattling && (
              <div className="flex flex-col items-center gap-6 animate-in zoom-in duration-500 bg-slate-900/80 backdrop-blur p-8 rounded-3xl border border-slate-700 shadow-2xl">
                 <div className={`text-5xl font-black flex items-center gap-4 ${battleState === 'won' ? 'text-yellow-400 drop-shadow-[0_0_20px_rgba(250,204,21,0.5)]' : 'text-slate-500'}`}>
                  {battleState === 'won' ? <><Trophy size={56} /> +{25 + (((profile?.aiLevel || 1) - 1) * 25)} POINTS!</> : <><Skull size={56} /> DEFEATED</>}
                 </div>
                 <button 
                   onClick={() => setBattleState('idle')} 
                   className="bg-white text-slate-900 px-8 py-3 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                 >
                   FIGHT AGAIN
                 </button>
              </div>
            )}
            
            <div className="bg-slate-900 w-full max-w-2xl rounded-2xl p-6 font-mono text-sm text-slate-400 h-64 overflow-y-auto flex flex-col-reverse border border-slate-800 shadow-inner">
              {log.map((l, i) => (
                <div key={i} className={`mb-3 border-b border-slate-800/50 pb-3 flex items-start gap-3 ${i === 0 ? 'text-white font-bold text-base' : ''}`}>
                  <span className="text-slate-600">[{log.length - i}]</span> {l}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
