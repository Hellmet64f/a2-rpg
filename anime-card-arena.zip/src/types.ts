export interface UserProfile {
  id: string;
  displayName: string;
  email: string;
  photoURL?: string;
  rank?: number;
  points?: number;
  lastClaimDate?: string;
  streakCount?: number;
  aiLevel?: number;
  aiWins?: number;
  createdAt: number;
}

export interface Card {
  id: string;
  name: string;
  anime: string;
  power: number;
  resistance: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary' | 'mythic';
  imageURL: string;
  createdAt?: number;
  level?: number;
  isShiny?: boolean;
}

export interface UserCard {
  id: string;
  cardId: string;
  acquiredAt: number;
  level?: number;
  cardName?: string;
  cardData?: Card; // Joined client-side
}

export interface Battle {
  id: string;
  player1Id: string;
  player2Id?: string;
  status: 'waiting' | 'playing' | 'finished';
  winnerId?: string;
  turn?: string;
  state?: string;
  createdAt: number;
  updatedAt: number;
}

export interface MarketListing {
  id: string;
  sellerId: string;
  userCardId: string;
  price: number;
  status: 'open' | 'sold' | 'cancelled';
  createdAt: number;
  cardData?: Card; // Joined client-side
}
