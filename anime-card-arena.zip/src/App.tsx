/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './lib/useAuth';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Arena from './pages/Arena';
import Market from './pages/Market';
import Collection from './pages/Collection';
import Friends from './pages/Friends';

import Shop from './pages/Shop';
import AiBattle from './pages/AiBattle';

export default function App() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100 flex items-center justify-center">
        <div className="animate-pulse text-2xl font-bold tracking-widest text-blue-400">LOADING...</div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/arena" element={<Arena />} />
          <Route path="/market" element={<Market />} />
          <Route path="/collection" element={<Collection />} />
          <Route path="/friends" element={<Friends />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/training" element={<AiBattle />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </Router>
  );
}
