import { useState, useEffect } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { auth, db } from './firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { UserProfile } from '../types';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        const unsubscribeProfile = onSnapshot(doc(db, 'users2', currentUser.uid), async (docSnap) => {
          if (docSnap.exists()) {
            setProfile({ id: docSnap.id, ...docSnap.data() } as UserProfile);
          } else {
            setProfile(null);
            // Fallback to create profile if it doesn't exist for an authenticated user
            try {
              const { setDoc } = await import('firebase/firestore');
              await setDoc(doc(db, 'users2', currentUser.uid), {
                displayName: currentUser.displayName || 'Player',
                email: currentUser.email || '',
                photoURL: currentUser.photoURL || '',
                rank: 0,
                points: 1000,
                createdAt: Date.now()
              });
            } catch (err) {
              console.error("Failed to auto-create profile", err);
            }
          }
          setLoading(false);
        });
        return () => unsubscribeProfile();
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  return { user, profile, loading };
}
