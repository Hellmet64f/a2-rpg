export const IMGBB_API_KEY = '7027d5fd66f02407d8e0b2dfa33ced67';

export const uploadImageToImgBB = async (file: File): Promise<string> => {
  const formData = new FormData();
  formData.append('image', file);
  
  const response = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`, {
    method: 'POST',
    body: formData,
  });
  
  if (!response.ok) {
    throw new Error('Failed to upload image');
  }
  
  const data = await response.json();
  return data.data.url;
};

// Catbox allows files up to 200mb
export const uploadVideoToCatbox = async (file: File): Promise<string> => {
  if (file.size > 200 * 1024 * 1024) {
    throw new Error('File exceeds 200MB limit');
  }

  const formData = new FormData();
  formData.append('reqtype', 'fileupload');
  formData.append('fileToUpload', file);

  const response = await fetch('https://catbox.moe/user/api.php', {
    method: 'POST',
    body: formData,
    // Catbox requires CORS for direct upload, or a proxy. We'll use a direct request.
    // In a real app, you might need a backend proxy to avoid CORS issues if Catbox doesn't allow it.
  });

  if (!response.ok) {
    throw new Error('Failed to upload video');
  }

  const url = await response.text();
  return url;
};
