import { Card } from '../types';

const FALLBACK_IMAGES: Record<string, string> = {
  "goku": "https://upload.wikimedia.org/wikipedia/en/3/36/Goku_-_Dragon_Ball.jpg",
  "naruto": "https://upload.wikimedia.org/wikipedia/en/9/94/NarutoCoverTankobon1.jpg",
  "luffy": "https://upload.wikimedia.org/wikipedia/en/a/a4/Monkey_D._Luffy.png",
  "ichigo": "https://upload.wikimedia.org/wikipedia/en/a/a8/Ichigo_Kurosaki.jpg",
  "midoriya": "https://upload.wikimedia.org/wikipedia/en/5/5a/Izuku_Midoriya.png",
  "vegeta": "https://upload.wikimedia.org/wikipedia/en/1/1a/Vegeta_in_Dragon_Ball.jpg",
  "sasuke": "https://upload.wikimedia.org/wikipedia/en/9/93/Sasuke_Uchiha.jpg",
  "zoro": "https://upload.wikimedia.org/wikipedia/en/a/a4/Roronoa_Zoro.jpg",
  "killua": "https://upload.wikimedia.org/wikipedia/en/6/65/Killua_Zoldyck.png",
  "gon": "https://upload.wikimedia.org/wikipedia/en/9/92/Gon_Freecss.png",
  "kakashi": "https://upload.wikimedia.org/wikipedia/en/2/27/Kakashi_Hatake.jpg",
  "saitama": "https://upload.wikimedia.org/wikipedia/en/c/c3/Saitama_anime.png",
  "eren": "https://upload.wikimedia.org/wikipedia/en/f/f6/Eren_Yeager.png",
  "levi": "https://upload.wikimedia.org/wikipedia/en/e/eb/Levi_Ackermann.png",
  "tanjiro": "https://upload.wikimedia.org/wikipedia/en/c/c5/Tanjiro_Kamado.png",
  "nezuko": "https://upload.wikimedia.org/wikipedia/en/6/65/Nezuko_Kamado.png"
};


const ANIME_SERIES = ["Dragon Ball", "Naruto", "One Piece", "Bleach", "Hunter x Hunter", "My Hero Academia"];

// Pseudo-random deterministic generator to act as our "robot"
function mulberry32(a: number) {
  return function() {
    var t = a += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
}

function stringToSeed(str: string) {
  let seed = 0;
  for (let i = 0; i < str.length; i++) {
    seed = str.charCodeAt(i) + (seed << 6) + (seed << 16) - seed;
  }
  return seed;
}

export async function generateCardData(characterName: string): Promise<Omit<Card, 'id' | 'createdAt'>> {
  const seed = stringToSeed(characterName.toLowerCase());
  const rand = mulberry32(seed);

  const animeIndex = Math.floor(rand() * ANIME_SERIES.length);
  const anime = ANIME_SERIES[animeIndex];
  
  // Power scaling: Some are OP (Goku), some are weak.
  // We use the rand to determine a base power, and rarity.
  const powerRoll = rand();
  let rarity: Card['rarity'] = 'common';
  let powerBase = 10;

  if (powerRoll > 0.95) {
    rarity = 'legendary';
    powerBase = 90;
  } else if (powerRoll > 0.8) {
    rarity = 'epic';
    powerBase = 70;
  } else if (powerRoll > 0.5) {
    rarity = 'rare';
    powerBase = 40;
  }

  const power = Math.floor(powerBase + (rand() * 10));
  const resistance = Math.floor((powerBase * 0.8) + (rand() * 20));

  // We try to get image from Jikan API, otherwise fallback to dicebear
  
  const normalizedName = characterName.toLowerCase().split(' ')[0]; // Basic matching
  
    let imageURL = FALLBACK_IMAGES[normalizedName] || FALLBACK_IMAGES[characterName.toLowerCase()];
    
    if (!imageURL) {
      try {
        const charRes = await fetch(`https://api.jikan.moe/v4/characters?q=${encodeURIComponent(characterName)}&limit=1`);
        const charJson = await charRes.json();
        
        if (charJson.data && charJson.data.length > 0) {
          imageURL = charJson.data[0].images.jpg.image_url;
        } else {
          const animeRes = await fetch(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(anime)}&limit=1`);
          const animeJson = await animeRes.json();
          
          if (animeJson.data && animeJson.data.length > 0) {
            const animeId = animeJson.data[0].mal_id;
            const charsRes = await fetch(`https://api.jikan.moe/v4/anime/${animeId}/characters`);
            const charsJson = await charsRes.json();
            
            if (charsJson.data && charsJson.data.length > 0) {
              const randomChar = charsJson.data[Math.floor(Math.random() * Math.min(20, charsJson.data.length))];
              imageURL = randomChar.character.images.jpg.image_url;
            }
          }
        }
      } catch (e) {
        console.warn("API Error", e);
      }
    }
    
    if (!imageURL) {
      imageURL = `https://api.dicebear.com/7.x/pixel-art/svg?seed=${characterName.replace(/\s+/g, '')}`;
    }
  

  return {
    name: characterName,
    anime,
    power,
    resistance,
    rarity,
    imageURL
  };
}
