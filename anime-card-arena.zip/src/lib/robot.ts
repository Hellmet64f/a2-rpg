import { Card } from '../types';

const FALLBACK_IMAGES: Record<string, string> = {
  "goku": "https://upload.wikimedia.org/wikipedia/en/3/36/Goku_-_Dragon_Ball.jpg",
  "naruto": "https://upload.wikimedia.org/wikipedia/en/9/94/NarutoCoverTankobon1.jpg",
  "luffy": "https://upload.wikimedia.org/wikipedia/en/a/a4/Monkey_D._Luffy.png",
  "ichigo": "https://upload.wikimedia.org/wikipedia/en/a/a8/Ichigo_Kurosaki.jpg",
  "midoriya": "https://upload.wikimedia.org/wikipedia/en/5/5a/Izuku_Midoriya.png",
  "vegeta": "https://upload.wikimedia.org/wikipedia/en/1/1a/Vegeta_in_Dragon_Ball.jpg",
  "sasuke": "https://upload.wikimedia.org/wikipedia/en/9/93/Sasuke_Uchiha.jpg",
  "zoro": "https://upload.wikimedia.org/wikipedia/en/a/a4/Roronoa_Zoro.jpg",
  "killua": "https://upload.wikimedia.org/wikipedia/en/6/65/Killua_Zoldyck.png",
  "gon": "https://upload.wikimedia.org/wikipedia/en/9/92/Gon_Freecss.png",
  "kakashi": "https://upload.wikimedia.org/wikipedia/en/2/27/Kakashi_Hatake.jpg",
  "saitama": "https://upload.wikimedia.org/wikipedia/en/c/c3/Saitama_anime.png",
  "eren": "https://upload.wikimedia.org/wikipedia/en/f/f6/Eren_Yeager.png",
  "levi": "https://upload.wikimedia.org/wikipedia/en/e/eb/Levi_Ackermann.png",
  "tanjiro": "https://upload.wikimedia.org/wikipedia/en/c/c5/Tanjiro_Kamado.png",
  "nezuko": "https://upload.wikimedia.org/wikipedia/en/6/65/Nezuko_Kamado.png"
};


// Banco de dados simulado de 570 animes de ação/luta (representado pelos mais famosos)
export const ANIME_DATABASE = [
  "Dragon Ball Z", "Naruto Shippuden", "One Piece", "Bleach", "Hunter x Hunter", 
  "My Hero Academia", "Jujutsu Kaisen", "Demon Slayer", "Attack on Titan", "Fullmetal Alchemist: Brotherhood",
  "JoJo's Bizarre Adventure", "Yu Yu Hakusho", "Fairy Tail", "Black Clover", "Sword Art Online",
  "One Punch Man", "Mob Psycho 100", "Tokyo Ghoul", "Akame ga Kill!", "Seven Deadly Sins",
  "Fate/stay night", "Gintama", "Hajime no Ippo", "Baki", "Kengan Ashura", "Soul Eater",
  "Evangelion", "Code Geass", "Gurren Lagann", "Kill la Kill", "Chainsaw Man", "Record of Ragnarok"
  // ... imaginando +500 animes aqui
];

const MYTHIC_CHARS: Record<string, string[]> = {
  "Dragon Ball Z": ["Goku", "Vegeta", "Gohan", "Frieza"],
  "Naruto Shippuden": ["Naruto Uzumaki", "Sasuke Uchiha", "Madara Uchiha", "Itachi Uchiha"],
  "One Piece": ["Monkey D. Luffy", "Zoro", "Kaido", "Shanks"],
  "Jujutsu Kaisen": ["Ryomen Sukuna", "Satoru Gojo", "Yuta Okkotsu"],
  "Demon Slayer": ["Tanjiro Kamado", "Muzan Kibutsuji", "Yoriichi Tsugikuni"],
  "Hunter x Hunter": ["Gon Freecss", "Killua Zoldyck", "Meruem", "Isaac Netero"],
  "Attack on Titan": ["Eren Yeager", "Levi Ackerman", "Mikasa Ackerman"],
  "Bleach": ["Ichigo Kurosaki", "Sosuke Aizen", "Kenpachi Zaraki"]
};

// Utilitários de seed
function mulberry32(a: number) {
  return function() {
    var t = a += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
}

function stringToSeed(str: string) {
  let seed = 0;
  for (let i = 0; i < str.length; i++) {
    seed = str.charCodeAt(i) + (seed << 6) + (seed << 16) - seed;
  }
  return seed;
}

// ROBO 1: Gerador de dados
// Responsável por pesquisar no banco de dados e criar os atributos baseados na série
export const robo1 = {
  
  getAnimeData: (animeName: string, seedVal: number) => {
    const rand = mulberry32(seedVal);
    // Raridades:
    // Common (0-60%)
    // Epic (60-85%)
    // Legendary (85-98%)
    // Mythic (98-100%)
    const roll = rand();
    let rarity: Card['rarity'] = 'common';
    let basePower = 10;
    
    if (roll > 0.98) {
      rarity = 'mythic';
      basePower = 150;
    } else if (roll > 0.85) {
      rarity = 'legendary';
      basePower = 90;
    } else if (roll > 0.60) {
      rarity = 'epic';
      basePower = 50;
    } else {
      rarity = 'common';
      basePower = 20;
    }

    const power = Math.floor(basePower + (rand() * 20));
    const resistance = Math.floor((basePower * 0.8) + (rand() * 15));
    
    const shinyRoll = rand();
    const isShiny = shinyRoll > 0.95;

    return { 
      rarity, 
      power: isShiny ? Math.floor(power * 1.5) : power, 
      resistance: isShiny ? Math.floor(resistance * 1.5) : resistance, 
      isShiny,
      rand 
    };
  },

  
  generateCharacterName: (anime: string, rand: () => number, rarity: string) => {
    // Se for mythic, pega da lista oficial.
    if (rarity === 'mythic' || rarity === 'legendary') {
      const mythics = MYTHIC_CHARS[anime];
      if (mythics) {
        return mythics[Math.floor(rand() * mythics.length)];
      }
    }
    // Senão, gera um nome aleatório baseado no anime
    const prefixes = ["Shin", "Kuro", "Aka", "Yami", "Ao", "Shiro", "Gin", "Kin"];
    const suffixes = ["maru", "taro", "shi", "ya", "ko", "ro", "suke"];
    return `${prefixes[Math.floor(rand() * prefixes.length)]}${suffixes[Math.floor(rand() * suffixes.length)]} of ${anime.split(' ')[0]}`;
  }
};

// ROBO 2: Processador de Informações
// Conecta os dados e formata o card
export const robo2 = {
  createCard: async (anime: string, uniqueId: number): Promise<Omit<Card, 'id' | 'createdAt'>> => {
    const data = robo1.getAnimeData(anime, uniqueId);
    
    const displayRarity = data.rarity;

    const name = robo1.generateCharacterName(anime, data.rand, data.rarity);
    
    const normalizedName = name.toLowerCase().split(' ')[0];
    
    let imageURL = FALLBACK_IMAGES[normalizedName] || FALLBACK_IMAGES[name.toLowerCase()];
    
    if (!imageURL) {
      try {
        // 1. Tenta buscar pelo nome do personagem
        const charRes = await fetch(`https://api.jikan.moe/v4/characters?q=${encodeURIComponent(name)}&limit=1`);
        const charJson = await charRes.json();
        
        if (charJson.data && charJson.data.length > 0) {
          imageURL = charJson.data[0].images.jpg.image_url;
        } else {
          // 2. Se não achar o personagem, busca o anime e pega a foto de um personagem aleatório
          const animeRes = await fetch(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(anime)}&limit=1`);
          const animeJson = await animeRes.json();
          
          if (animeJson.data && animeJson.data.length > 0) {
            const animeId = animeJson.data[0].mal_id;
            const charsRes = await fetch(`https://api.jikan.moe/v4/anime/${animeId}/characters`);
            const charsJson = await charsRes.json();
            
            if (charsJson.data && charsJson.data.length > 0) {
              const randomChar = charsJson.data[Math.floor(Math.random() * Math.min(20, charsJson.data.length))];
              imageURL = randomChar.character.images.jpg.image_url;
            }
          }
        }
      } catch (e) {
        console.warn("API Error", e);
      }
    }
    
    if (!imageURL) {
      // Fallback final
      imageURL = `https://api.dicebear.com/7.x/pixel-art/svg?seed=${name.replace(/\s+/g, '')}`;
    }


    
    return {
      name,
      anime,
      power: data.power,
      resistance: data.resistance,
      rarity: displayRarity as Card['rarity'],
      imageURL,
      isShiny: data.isShiny
    };

  }
};

// ROBO 3: Abridor de Pacotes e Validador
// Verifica se o personagem gerado pertence ao pacote correto e garante as regras.
export const robo3 = {
  // A cada 5 horas, a loja atualiza os animes em destaque
  getCurrentShopPacks: () => {
    const EPOCH_5H = Math.floor(Date.now() / (5 * 60 * 60 * 1000));
    const rand = mulberry32(EPOCH_5H);
    
    const packs = [];
    const dbCopy = [...ANIME_DATABASE];
    
    for(let i=0; i<4; i++) {
      const idx = Math.floor(rand() * dbCopy.length);
      packs.push(dbCopy.splice(idx, 1)[0]);
    }
    return packs;
  },

  openPack: async (animeName: string): Promise<Omit<Card, 'id' | 'createdAt'>> => {
    // Validação: Garante que o card gerado vai ser DESTE anime especificamente.
    // O Robo 3 valida a procedência.
    const uniqueSeed = Date.now() + Math.random() * 10000;
    const card = await robo2.createCard(animeName, uniqueSeed);
    
    // Verificação de segurança de lore (ex: Sukuna SÓ no pacote Jujutsu)
    if (card.name === "Ryomen Sukuna" && card.anime !== "Jujutsu Kaisen") {
      console.warn("Robo 3 detectou anomalia: Sukuna no anime errado. Corrigindo...");
      card.anime = "Jujutsu Kaisen";
    }
    
    return card;
  }
};
