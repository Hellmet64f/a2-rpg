import { X, Sparkles, Percent } from 'lucide-react';

interface PackInfoModalProps {
  anime: string | null;
  onClose: () => void;
}

const MYTHIC_CHARS: Record<string, string[]> = {
  "Dragon Ball Z": ["Goku", "Vegeta", "Gohan", "Frieza"],
  "Naruto Shippuden": ["Naruto Uzumaki", "Sasuke Uchiha", "Madara Uchiha", "Itachi Uchiha"],
  "One Piece": ["Monkey D. Luffy", "Zoro", "Kaido", "Shanks"],
  "Jujutsu Kaisen": ["Ryomen Sukuna", "Satoru Gojo", "Yuta Okkotsu"],
  "Demon Slayer": ["Tanjiro Kamado", "Muzan Kibutsuji", "Yoriichi Tsugikuni"],
  "Hunter x Hunter": ["Gon Freecss", "Killua Zoldyck", "Meruem", "Isaac Netero"],
  "Attack on Titan": ["Eren Yeager", "Levi Ackerman", "Mikasa Ackerman"],
  "Bleach": ["Ichigo Kurosaki", "Sosuke Aizen", "Kenpachi Zaraki"]
};

export default function PackInfoModal({ anime, onClose }: PackInfoModalProps) {
  if (!anime) return null;

  const highlights = MYTHIC_CHARS[anime];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black flex items-center gap-2 text-white">
            <Sparkles className="text-yellow-400" />
            {anime} Pack
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors p-1 bg-slate-800 rounded-full">
            <X size={20} />
          </button>
        </div>

        <div className="space-y-6">
          {highlights && (
            <div>
              <h3 className="text-sm font-bold text-slate-400 mb-2 uppercase tracking-wider">Top Pulls Available</h3>
              <div className="flex flex-wrap gap-2">
                {highlights.map(c => (
                  <span key={c} className="px-3 py-1 bg-slate-800 text-slate-300 rounded-lg text-sm font-medium border border-slate-700">
                    {c}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div>
             <h3 className="text-sm font-bold text-slate-400 mb-2 uppercase tracking-wider flex items-center gap-1"><Percent size={14} /> Drop Rates</h3>
             <ul className="space-y-2 bg-slate-950 p-4 rounded-xl border border-slate-800">
               <li className="flex justify-between items-center text-sm">
                 <span className="text-slate-500 font-bold">Common</span> <span className="text-white">60%</span>
               </li>
               <li className="flex justify-between items-center text-sm">
                 <span className="text-purple-400 font-bold">Epic</span> <span className="text-white">25%</span>
               </li>
               <li className="flex justify-between items-center text-sm">
                 <span className="text-yellow-400 font-bold">Legendary</span> <span className="text-white">13%</span>
               </li>
               <li className="flex justify-between items-center text-sm">
                 <span className="text-red-500 font-black">Mythic</span> <span className="text-white">2%</span>
               </li>
             </ul>
          </div>

          <div className="bg-yellow-900/20 text-yellow-400 p-4 rounded-xl border border-yellow-800/50 text-sm font-medium text-center">
            ⭐ 5% chance for any card to be SHINY (+50% Stats)
          </div>
          
          <button
            onClick={onClose}
            className="w-full bg-slate-800 hover:bg-slate-700 text-white py-3 rounded-xl font-bold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
