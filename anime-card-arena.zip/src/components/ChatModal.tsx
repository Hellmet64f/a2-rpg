import { useState, useEffect, useRef } from 'react';
import { X, Send, Loader2 } from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp } from 'firebase/firestore';

interface ChatModalProps {
  userUid: string;
  friendId: string;
  friendName: string;
  onClose: () => void;
}

export default function ChatModal({ userUid, friendId, friendName, onClose }: ChatModalProps) {
  const [messages, setMessages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const chatId = [userUid, friendId].sort().join('_');

  useEffect(() => {
    const q = query(collection(db, 'chats2', chatId, 'messages'), orderBy('createdAt', 'asc'));
    const unsub = onSnapshot(q, (snap) => {
      setMessages(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    });
    return unsub;
  }, [chatId]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    const msg = input.trim();
    setInput('');
    try {
      await addDoc(collection(db, 'chats2', chatId, 'messages'), {
        text: msg,
        senderId: userUid,
        createdAt: serverTimestamp()
      });
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-lg shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col h-[600px] max-h-[80vh]">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <h2 className="text-xl font-bold flex items-center gap-2">
            Chat with <span className="text-blue-400">{friendName}</span>
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors p-1 bg-slate-800 rounded-full">
            <X size={20} />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {loading ? (
             <div className="flex justify-center p-4"><Loader2 className="animate-spin text-slate-500" /></div>
          ) : messages.length === 0 ? (
             <div className="text-center text-slate-500 mt-10">No messages yet. Say hi!</div>
          ) : (
            messages.map(m => {
              const isMe = m.senderId === userUid;
              return (
                <div key={m.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                  <div className={`px-4 py-2 rounded-2xl max-w-[80%] ${isMe ? 'bg-blue-600 text-white rounded-br-none' : 'bg-slate-800 text-slate-200 rounded-bl-none'}`}>
                    {m.text}
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>
        
        <form onSubmit={handleSend} className="p-4 border-t border-slate-800 flex gap-2">
           <input 
             type="text"
             value={input}
             onChange={e => setInput(e.target.value)}
             className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2 text-white focus:outline-none focus:border-blue-500"
             placeholder="Type a message..."
             autoFocus
           />
           <button type="submit" disabled={!input.trim()} className="p-3 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white rounded-xl transition-colors">
             <Send size={18} />
           </button>
        </form>
      </div>
    </div>
  );
}
