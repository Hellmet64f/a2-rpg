import { useState } from 'react';
import { Coins, X, Loader2 } from 'lucide-react';

interface SellModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSell: (price: number) => Promise<void>;
  defaultPrice?: number;
}

export default function SellModal({ isOpen, onClose, onSell, defaultPrice = 100 }: SellModalProps) {
  const [price, setPrice] = useState(defaultPrice.toString());
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseInt(price);
    if (isNaN(parsed) || parsed <= 0) {
      alert("Please enter a valid positive number.");
      return;
    }
    
    setLoading(true);
    await onSell(parsed);
    setLoading(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black flex items-center gap-2">
            <Coins className="text-yellow-400" />
            List on Market
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors p-1 bg-slate-800 rounded-full">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-2">Price (in points)</label>
            <input 
              type="number"
              min="1"
              required
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-lg font-bold focus:outline-none focus:border-blue-500 transition-colors"
              value={price}
              onChange={e => setPrice(e.target.value)}
              placeholder="e.g. 100"
            />
          </div>
          
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-3 rounded-xl font-bold transition-colors"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 bg-green-600 hover:bg-green-500 text-white py-3 rounded-xl font-bold transition-colors flex items-center justify-center gap-2"
              disabled={loading}
            >
              {loading ? <Loader2 size={18} className="animate-spin" /> : <Coins size={18} />}
              Confirm Listing
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
