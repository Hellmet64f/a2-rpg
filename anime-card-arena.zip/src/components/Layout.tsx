import React, { ReactNode } from 'react';
import { NavLink } from 'react-router-dom';
import { logOut } from '../lib/firebase';
import { useAuth } from '../lib/useAuth';
import { Gamepad2, Store, Users, LogOut, WalletCards, PackageOpen, Bot } from 'lucide-react';
import { uploadImageToImgBB } from '../lib/upload';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';

export default function Layout({ children }: { children: ReactNode }) {
  const { profile } = useAuth();

  const handleProfileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !profile) return;
    try {
      const url = await uploadImageToImgBB(file);
      await updateDoc(doc(db, 'users2', profile.id), { photoURL: url });
    } catch (error) {
      console.error('Upload failed', error);
      alert('Failed to upload profile picture.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col md:flex-row font-sans selection:bg-blue-500/30">
      <nav className="w-full md:w-64 bg-slate-800 border-b md:border-r border-slate-700 p-6 flex flex-col">
        <div className="flex items-center gap-3 mb-12">
          <div className="bg-gradient-to-tr from-blue-500 to-indigo-500 text-white p-2 rounded-xl">
            <WalletCards size={28} />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-white">Anime Arena</h1>
        </div>

        <div className="flex-1 space-y-2">
          <NavItem to="/" icon={<Gamepad2 size={20} />} label="Dashboard" />
          <NavItem to="/arena" icon={<Users size={20} />} label="Battle Arena" />
          <NavItem to="/training" icon={<Bot size={20} />} label="AI Training" />
          <NavItem to="/collection" icon={<WalletCards size={20} />} label="Collection" />
          <NavItem to="/market" icon={<Store size={20} />} label="Market" />
          <NavItem to="/shop" icon={<PackageOpen size={20} />} label="Shop & Packs" />
          <NavItem to="/friends" icon={<Users size={20} />} label="Friends" />
        </div>

        {profile && (
          <div className="mt-8 pt-8 border-t border-slate-700 flex flex-col gap-4">
            <div className="flex items-center gap-3 group relative cursor-pointer">
              <label className="cursor-pointer relative overflow-hidden rounded-full ring-2 ring-slate-700 group-hover:ring-blue-500 transition-all">
                <img 
                  src={profile.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.displayName}`} 
                  alt={profile.displayName} 
                  className="w-12 h-12 object-cover"
                />
                <div className="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center text-[10px] font-bold">
                  EDIT
                </div>
                <input type="file" className="hidden" accept="image/*" onChange={handleProfileUpload} />
              </label>
              <div className="flex flex-col">
                <span className="font-medium text-sm">{profile.displayName}</span>
                <span className="text-xs text-slate-400">Rank: {profile.rank || 1} • {profile.points || 0} pts</span>
              </div>
            </div>
            
            <button 
              onClick={logOut}
              className="flex items-center gap-2 text-slate-400 hover:text-red-400 transition-colors text-sm px-2 py-2 rounded-lg hover:bg-slate-700/50"
            >
              <LogOut size={16} />
              Sign Out
            </button>
          </div>
        )}
      </nav>

      <main className="flex-1 p-6 lg:p-12 overflow-y-auto">
        <div className="max-w-6xl mx-auto w-full">
          {children}
        </div>
      </main>
    </div>
  );
}

function NavItem({ to, icon, label }: { to: string; icon: ReactNode; label: string }) {
  return (
    <NavLink 
      to={to} 
      className={({ isActive }) => 
        `flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${
          isActive 
            ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20 shadow-[0_0_15px_rgba(59,130,246,0.1)]' 
            : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50 border border-transparent'
        }`
      }
    >
      {icon}
      {label}
    </NavLink>
  );
}
