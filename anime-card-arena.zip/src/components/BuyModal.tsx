import { useState } from 'react';
import { Coins, X, Loader2, Tag } from 'lucide-react';
import { MarketListing, Card } from '../types';
import AnimeCard from './AnimeCard';

interface BuyModalProps {
  listing: (MarketListing & { cardData: Card }) | null;
  onClose: () => void;
  onBuy: (listing: MarketListing) => Promise<void>;
  userPoints: number;
}

export default function BuyModal({ listing, onClose, onBuy, userPoints }: BuyModalProps) {
  const [loading, setLoading] = useState(false);

  if (!listing) return null;
  
  const canAfford = userPoints >= listing.price;

  const handleBuy = async () => {
    if (!canAfford) return;
    setLoading(true);
    await onBuy(listing);
    setLoading(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black flex items-center gap-2">
            <Tag className="text-blue-400" />
            Buy Card
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors p-1 bg-slate-800 rounded-full">
            <X size={20} />
          </button>
        </div>
        
        <div className="flex flex-col items-center gap-6">
          <div className="w-48">
            <AnimeCard card={listing.cardData} />
          </div>
          
          <div className="text-center">
            <p className="text-slate-400 mb-2">Are you sure you want to buy <span className="text-white font-bold">{listing.cardData.name}</span>?</p>
            <div className="flex items-center justify-center gap-2 text-2xl font-black">
              <Coins className="text-yellow-400" size={24} />
              {listing.price} Points
            </div>
          </div>
          
          {!canAfford && (
            <div className="text-red-400 font-medium text-sm bg-red-900/20 px-4 py-2 rounded-xl">
              You do not have enough points.
            </div>
          )}

          <div className="flex gap-3 w-full">
            <button
              onClick={onClose}
              className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-3 rounded-xl font-bold transition-colors"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              onClick={handleBuy}
              disabled={loading || !canAfford}
              className="flex-1 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white py-3 rounded-xl font-bold transition-colors flex items-center justify-center gap-2 shadow-lg"
            >
              {loading ? <Loader2 size={18} className="animate-spin" /> : <Tag size={18} />}
              Confirm Purchase
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
