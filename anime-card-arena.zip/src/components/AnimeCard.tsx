import React from 'react';
import { Card } from '../types';

interface AnimeCardProps {
  card: Card;
  className?: string;
  onClick?: () => void;
  selected?: boolean;
  key?: string | number;
}

const RarityColors: Record<string, string> = {
  common: 'from-slate-500 to-slate-700',
  rare: 'from-blue-500 to-blue-700',
  epic: 'from-purple-500 to-purple-800',
  legendary: 'from-yellow-400 to-orange-500',
  mythic: 'from-red-500 to-rose-900'
};

const RarityBorders: Record<string, string> = {
  common: 'border-slate-500',
  rare: 'border-blue-500',
  epic: 'border-purple-500',
  legendary: 'border-yellow-400',
  mythic: 'border-red-500'
};

export default function AnimeCard({ card, className = '', onClick, selected = false }: AnimeCardProps) {
  const gradient = RarityColors[card.rarity] || RarityColors.common;
  const border = RarityBorders[card.rarity] || RarityBorders.common;

  return (
    <div 
      onClick={onClick}
      className={`relative group rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 transform bg-slate-900 shadow-xl ${
        selected ? 'scale-105 shadow-[0_0_30px_rgba(255,255,255,0.2)] ring-4 ring-white' : 'hover:-translate-y-2 hover:shadow-2xl border-2 ' + border
      } ${
        card.isShiny ? 'ring-4 ring-yellow-400 animate-pulse shadow-[0_0_30px_rgba(250,204,21,0.6)]' : ''
      } ${className}`}
    >
      {/* Background Image with Gradient Overlay */}
      <div className="absolute inset-0 bg-cover bg-center opacity-40 group-hover:opacity-60 transition-opacity" style={{ backgroundImage: `url(${card.imageURL})` }} />
      <div className={`absolute inset-0 bg-gradient-to-b ${gradient} mix-blend-multiply opacity-80`} />
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/80 to-transparent" />
      
      {/* Content */}
      <div className="relative p-4 flex flex-col h-full z-10">
        <div className="flex justify-between items-start mb-2">
          <span className="text-[10px] font-black uppercase tracking-widest px-2 py-1 bg-black/50 rounded-full backdrop-blur-md border border-white/10 text-white shadow-sm flex items-center gap-1">
            {card.rarity}
            {card.level && card.level > 1 && (
               <span className="text-yellow-400 font-black">★{card.level}</span>
            )}
          </span>
          <span className="text-[10px] font-bold text-slate-300 px-2 py-1 bg-black/40 rounded-full truncate max-w-[100px]">
            {card.anime}
          </span>
        </div>
        
        <div className="flex-1 flex items-center justify-center py-4 pointer-events-none">
           <img
              src={card.imageURL}
              alt={card.name}
              className="w-24 h-24 sm:w-32 sm:h-32 object-cover rounded-xl shadow-2xl border-2 border-white/20 transform group-hover:scale-110 transition-transform duration-500 bg-slate-800"
            />
        </div>
        
        <div className="text-center mt-auto pointer-events-none">
          <h3 className="text-lg font-black text-white leading-tight drop-shadow-md mb-3 line-clamp-1">{card.name}</h3>
          
          <div className="grid grid-cols-2 gap-2 w-full">
            <div className="bg-black/50 backdrop-blur-md rounded-lg p-2 border border-white/10 flex pointer-events-auto flex-col items-center justify-center">
              <span className="text-[9px] text-slate-400 font-bold mb-1">PWR</span>
              <span className="text-red-400 font-black text-sm">{Math.floor(card.power * (1 + ((card.level || 1) - 1) * 0.2))}</span>
            </div>
            <div className="bg-black/50 backdrop-blur-md rounded-lg p-2 border border-white/10 flex pointer-events-auto flex-col items-center justify-center">
              <span className="text-[9px] text-slate-400 font-bold mb-1">RES</span>
              <span className="text-green-400 font-black text-sm">{Math.floor(card.resistance * (1 + ((card.level || 1) - 1) * 0.2))}</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Highlight effect */}
      <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/0 to-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
    </div>
  );
}
